import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { useColorScheme } from "react-native";
import { ref, onValue, set } from "firebase/database";
import { db } from "@/lib/firebase";
import { lightTheme, darkTheme, anniversaryTheme, ThemeColors } from "@/constants/colors";

type ThemeMode = "light" | "dark";

interface ThemeContextValue {
  theme: ThemeColors;
  isDark: boolean;
  isAnniversary: boolean;
  themeMode: ThemeMode;
  toggleTheme: () => void;
  setThemeMode: (mode: ThemeMode) => void;
}

const ThemeContext = createContext<ThemeContextValue | null>(null);

interface ThemeProviderProps {
  children: ReactNode;
  userId?: string | null;
  anniversaryDate?: string | null;
}

function checkIsAnniversaryToday(anniversaryDate?: string | null): boolean {
  if (!anniversaryDate) return false;
  const today = new Date();
  const ann = new Date(anniversaryDate);
  return (
    today.getMonth() === ann.getMonth() && today.getDate() === ann.getDate()
  );
}

export function ThemeProvider({ children, userId, anniversaryDate }: ThemeProviderProps) {
  const systemColorScheme = useColorScheme();
  const [themeMode, setThemeModeState] = useState<ThemeMode>(
    systemColorScheme === "dark" ? "dark" : "light"
  );
  const [loaded, setLoaded] = useState(false);

  const isAnniversary = checkIsAnniversaryToday(anniversaryDate);

  useEffect(() => {
    if (!userId) return;
    const darkModeRef = ref(db, `users/${userId}/settings/darkMode`);
    const unsub = onValue(darkModeRef, (snap) => {
      if (snap.exists()) {
        setThemeModeState(snap.val() === true ? "dark" : "light");
      }
      setLoaded(true);
    });
    return () => unsub();
  }, [userId]);

  const toggleTheme = () => {
    const newMode = themeMode === "dark" ? "light" : "dark";
    setThemeModeState(newMode);
    if (userId) {
      set(ref(db, `users/${userId}/settings/darkMode`), newMode === "dark");
    }
  };

  const setThemeMode = (mode: ThemeMode) => {
    setThemeModeState(mode);
    if (userId) {
      set(ref(db, `users/${userId}/settings/darkMode`), mode === "dark");
    }
  };

  const isDark = themeMode === "dark";

  let theme: ThemeColors;
  if (isAnniversary) {
    theme = anniversaryTheme;
  } else if (isDark) {
    theme = darkTheme;
  } else {
    theme = lightTheme;
  }

  return (
    <ThemeContext.Provider value={{ theme, isDark, isAnniversary, themeMode, toggleTheme, setThemeMode }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error("useTheme must be used within ThemeProvider");
  return ctx;
}
