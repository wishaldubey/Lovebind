import React, { createContext, useContext, useState, useEffect, useMemo, ReactNode } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut as firebaseSignOut,
  onAuthStateChanged,
  updateProfile,
  User as FirebaseUser,
} from "firebase/auth";
import { ref, set, get, onValue, update } from "firebase/database";
import { auth, db } from "@/lib/firebase";
import { registerForPushNotifications } from "@/lib/notifications";

interface UserProfile {
  uid: string;
  name: string;
  email: string;
  photoURL?: string;
  anniversaryDate?: string;
  coupleId?: string;
}

interface AuthContextValue {
  user: FirebaseUser | null;
  userProfile: UserProfile | null;
  partnerProfile: UserProfile | null;
  coupleId: string | null;
  anniversary: string | null;
  isLoading: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string, name: string) => Promise<void>;
  signOut: () => Promise<void>;
  createCoupleCode: () => Promise<string>;
  joinCouple: (code: string) => Promise<void>;
  updateUserProfile: (data: Partial<UserProfile>) => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [partnerProfile, setPartnerProfile] = useState<UserProfile | null>(null);
  const [coupleId, setCoupleId] = useState<string | null>(null);
  const [anniversary, setAnniversary] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      setUser(firebaseUser);
      if (firebaseUser) {
        const storedCoupleId = await AsyncStorage.getItem("coupleId");
        if (storedCoupleId) {
          setCoupleId(storedCoupleId);
        }
        const userRef = ref(db, `users/${firebaseUser.uid}`);
        const snap = await get(userRef);
        if (snap.exists()) {
          const data = snap.val();
          setUserProfile(data);
          if (data.coupleId) {
            setCoupleId(data.coupleId);
            await AsyncStorage.setItem("coupleId", data.coupleId);
          }
        }

        // Register push notifications
        registerForPushNotifications(firebaseUser.uid);
      } else {
        setUserProfile(null);
        setPartnerProfile(null);
        setCoupleId(null);
        setAnniversary(null);
        await AsyncStorage.removeItem("coupleId");
      }
      setIsLoading(false);
    });
    return unsubscribe;
  }, []);

  // Listen to partner profile
  useEffect(() => {
    if (!user || !coupleId) {
      setPartnerProfile(null);
      return;
    }
    const coupleRef = ref(db, `couples/${coupleId}/members`);
    const unsub = onValue(coupleRef, async (snap) => {
      if (!snap.exists()) return;
      const members: string[] = Object.keys(snap.val());
      const partnerId = members.find((id) => id !== user.uid);
      if (!partnerId) return;
      const partnerRef = ref(db, `users/${partnerId}`);
      const partnerSnap = await get(partnerRef);
      if (partnerSnap.exists()) {
        setPartnerProfile(partnerSnap.val());
      }
    });
    return () => unsub();
  }, [user, coupleId]);

  // Listen to anniversary
  useEffect(() => {
    if (!coupleId) {
      setAnniversary(null);
      return;
    }
    const annRef = ref(db, `couples/${coupleId}/anniversary`);
    const unsub = onValue(annRef, (snap) => {
      if (snap.exists()) {
        setAnniversary(snap.val());
      } else {
        setAnniversary(null);
      }
    });
    return () => unsub();
  }, [coupleId]);

  const signIn = async (email: string, password: string) => {
    const cred = await signInWithEmailAndPassword(auth, email, password);
    const userRef = ref(db, `users/${cred.user.uid}`);
    const snap = await get(userRef);
    if (snap.exists()) {
      const data = snap.val();
      setUserProfile(data);
      if (data.coupleId) {
        setCoupleId(data.coupleId);
        await AsyncStorage.setItem("coupleId", data.coupleId);
      }
    }
    registerForPushNotifications(cred.user.uid);
  };

  const signUp = async (email: string, password: string, name: string) => {
    const cred = await createUserWithEmailAndPassword(auth, email, password);
    await updateProfile(cred.user, { displayName: name });
    const profile: UserProfile = { uid: cred.user.uid, name, email };
    await set(ref(db, `users/${cred.user.uid}`), profile);
    setUserProfile(profile);
    registerForPushNotifications(cred.user.uid);
  };

  const signOut = async () => {
    await firebaseSignOut(auth);
    await AsyncStorage.removeItem("coupleId");
  };

  const createCoupleCode = async (): Promise<string> => {
    if (!user) throw new Error("Not authenticated");
    const code = Math.random().toString(36).substring(2, 8).toUpperCase();
    const newCoupleId = `couple_${user.uid}_${Date.now()}`;
    await set(ref(db, `coupleCodes/${code}`), {
      coupleId: newCoupleId,
      createdBy: user.uid,
      createdAt: Date.now(),
    });
    await set(ref(db, `couples/${newCoupleId}/members/${user.uid}`), true);
    await update(ref(db, `users/${user.uid}`), { coupleId: newCoupleId });
    setCoupleId(newCoupleId);
    await AsyncStorage.setItem("coupleId", newCoupleId);
    if (userProfile) setUserProfile({ ...userProfile, coupleId: newCoupleId } as any);
    return code;
  };

  const joinCouple = async (code: string) => {
    if (!user) throw new Error("Not authenticated");
    const codeRef = ref(db, `coupleCodes/${code.toUpperCase()}`);
    const snap = await get(codeRef);
    if (!snap.exists()) throw new Error("Invalid couple code");
    const { coupleId: cId } = snap.val();
    await set(ref(db, `couples/${cId}/members/${user.uid}`), true);
    await update(ref(db, `users/${user.uid}`), { coupleId: cId });
    setCoupleId(cId);
    await AsyncStorage.setItem("coupleId", cId);
    if (userProfile) setUserProfile({ ...userProfile, coupleId: cId } as any);
  };

  const updateUserProfile = async (data: Partial<UserProfile>) => {
    if (!user) return;
    await update(ref(db, `users/${user.uid}`), data);
    setUserProfile((prev) => (prev ? { ...prev, ...data } : null));
  };

  const value = useMemo(
    () => ({ user, userProfile, partnerProfile, coupleId, anniversary, isLoading, signIn, signUp, signOut, createCoupleCode, joinCouple, updateUserProfile }),
    [user, userProfile, partnerProfile, coupleId, anniversary, isLoading]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
