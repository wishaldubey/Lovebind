import React, { useState, useEffect, useRef, useCallback } from "react";
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  FlatList,
  Pressable,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
  Dimensions,
  Modal,
  ScrollView,
} from "react-native";
import { SafeAreaView, useSafeAreaInsets } from "react-native-safe-area-context";
import { ref, push, onValue, off, set, get, update, onDisconnect, serverTimestamp, query, orderByChild, limitToLast } from "firebase/database";
import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { LinearGradient } from "expo-linear-gradient";
import Animated, { useSharedValue, useAnimatedStyle, withRepeat, withTiming, withSequence } from "react-native-reanimated";
import { db } from "@/lib/firebase";
import { useAuth } from "@/context/AuthContext";
import { useTheme } from "@/context/ThemeContext";
import { scaledFont, MIN_BUTTON_HEIGHT, wp } from "@/lib/responsive";
import { sendPushNotification } from "@/lib/notifications";

const { width: SCREEN_WIDTH } = Dimensions.get("window");

interface Message {
  id: string;
  text: string;
  senderId: string;
  senderName: string;
  timestamp: number;
  status?: "sent" | "delivered" | "seen";
}

function TypingDots() {
  const dot1 = useSharedValue(0);
  const dot2 = useSharedValue(0);
  const dot3 = useSharedValue(0);

  useEffect(() => {
    dot1.value = withRepeat(withSequence(withTiming(-4, { duration: 300 }), withTiming(0, { duration: 300 })), -1, true);
    setTimeout(() => {
      dot2.value = withRepeat(withSequence(withTiming(-4, { duration: 300 }), withTiming(0, { duration: 300 })), -1, true);
    }, 150);
    setTimeout(() => {
      dot3.value = withRepeat(withSequence(withTiming(-4, { duration: 300 }), withTiming(0, { duration: 300 })), -1, true);
    }, 300);
  }, []);

  const s1 = useAnimatedStyle(() => ({ transform: [{ translateY: dot1.value }] }));
  const s2 = useAnimatedStyle(() => ({ transform: [{ translateY: dot2.value }] }));
  const s3 = useAnimatedStyle(() => ({ transform: [{ translateY: dot3.value }] }));

  return (
    <View style={{ flexDirection: "row", alignItems: "center", gap: 3 }}>
      <Animated.View style={[{ width: 6, height: 6, borderRadius: 3, backgroundColor: "#FF6B9D" }, s1]} />
      <Animated.View style={[{ width: 6, height: 6, borderRadius: 3, backgroundColor: "#FF6B9D" }, s2]} />
      <Animated.View style={[{ width: 6, height: 6, borderRadius: 3, backgroundColor: "#FF6B9D" }, s3]} />
    </View>
  );
}

function StatusTicks({ status }: { status?: string }) {
  if (!status || status === "sent") {
    return <Text style={{ fontSize: 11, color: "#aaa" }}>✓</Text>;
  }
  if (status === "delivered") {
    return <Text style={{ fontSize: 11, color: "#aaa" }}>✓✓</Text>;
  }
  if (status === "seen") {
    return <Text style={{ fontSize: 11, color: "#4FC3F7" }}>✓✓</Text>;
  }
  return null;
}

function MessageBubble({ message, isMe, theme }: { message: Message; isMe: boolean; theme: any }) {
  const time = new Date(message.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });

  return (
    <View style={[styles.bubbleRow, isMe && styles.bubbleRowMe]}>
      {!isMe && (
        <View style={[styles.avatar, { backgroundColor: theme.lavender }]}>
          <Text style={[styles.avatarText, { color: theme.deepLavender }]}>{message.senderName.charAt(0).toUpperCase()}</Text>
        </View>
      )}
      <View style={styles.bubbleGroup}>
        {!isMe && <Text style={[styles.senderName, { color: theme.textSecondary }]}>{message.senderName}</Text>}
        <View style={[styles.bubble, isMe ? { backgroundColor: theme.bubbleMine, borderBottomRightRadius: 4 } : { backgroundColor: theme.bubbleThem, borderBottomLeftRadius: 4 }]}>
          <Text style={[styles.bubbleText, { color: isMe ? theme.bubbleMineText : theme.bubbleThemText }]}>
            {message.text}
          </Text>
          {isMe && (
            <View style={{ alignSelf: "flex-end", marginTop: 2 }}>
              <StatusTicks status={message.status} />
            </View>
          )}
        </View>
        <Text style={[styles.timestamp, isMe && styles.timestampMe, { color: theme.textLight }]}>{time}</Text>
      </View>
    </View>
  );
}

function ChatStats({ messages, userId, partnerProfile, theme }: { messages: Message[]; userId: string; partnerProfile: any; theme: any }) {
  const myMsgs = messages.filter(m => m.senderId === userId);
  const partnerMsgs = messages.filter(m => m.senderId !== userId);
  const total = messages.length;
  const myPercent = total > 0 ? Math.round((myMsgs.length / total) * 100) : 50;
  const partnerPercent = 100 - myPercent;

  // Most active hour
  const hourCounts: Record<number, number> = {};
  messages.forEach(m => {
    const h = new Date(m.timestamp).getHours();
    hourCounts[h] = (hourCounts[h] || 0) + 1;
  });
  let bestHour = 0;
  let bestHourCount = 0;
  Object.entries(hourCounts).forEach(([h, c]) => {
    if (c > bestHourCount) { bestHour = parseInt(h); bestHourCount = c; }
  });
  const formatHour = (h: number) => {
    if (h === 0) return "12am";
    if (h < 12) return `${h}am`;
    if (h === 12) return "12pm";
    return `${h - 12}pm`;
  };

  // Chat streak
  const dayMsgs: Record<string, { me: boolean; partner: boolean }> = {};
  messages.forEach(m => {
    const day = new Date(m.timestamp).toISOString().split("T")[0];
    if (!dayMsgs[day]) dayMsgs[day] = { me: false, partner: false };
    if (m.senderId === userId) dayMsgs[day].me = true;
    else dayMsgs[day].partner = true;
  });
  const sortedDays = Object.keys(dayMsgs).sort().reverse();
  let streak = 0;
  for (const day of sortedDays) {
    if (dayMsgs[day].me && dayMsgs[day].partner) streak++;
    else break;
  }

  // Most used words
  const wordCounts: Record<string, number> = {};
  messages.forEach(m => {
    m.text.split(/\s+/).forEach(w => {
      const word = w.toLowerCase().replace(/[^a-z0-9❤️💕🥰😍😘💗💖🌸✨]/g, "");
      if (word.length > 2) wordCounts[word] = (wordCounts[word] || 0) + 1;
    });
  });
  const topWords = Object.entries(wordCounts).sort((a, b) => b[1] - a[1]).slice(0, 3);

  // Longest conversation day
  const dayCounts: Record<string, number> = {};
  messages.forEach(m => {
    const day = new Date(m.timestamp).toISOString().split("T")[0];
    dayCounts[day] = (dayCounts[day] || 0) + 1;
  });
  let longestDay = "";
  let longestCount = 0;
  Object.entries(dayCounts).forEach(([d, c]) => {
    if (c > longestCount) { longestDay = d; longestCount = c; }
  });

  const partnerName = partnerProfile?.name || "Partner";

  return (
    <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ padding: 20, gap: 16 }}>
      <Text style={[statStyles.title, { color: theme.text }]}>💬 Chat Stats</Text>

      <View style={[statStyles.card, { backgroundColor: theme.cardBg }]}>
        <Text style={[statStyles.label, { color: theme.textSecondary }]}>Total Messages</Text>
        <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
          <Text style={[statStyles.value, { color: theme.deepRose }]}>You: {myMsgs.length}</Text>
          <Text style={[statStyles.value, { color: theme.deepLavender }]}>{partnerName}: {partnerMsgs.length}</Text>
        </View>
        <View style={statStyles.barContainer}>
          <View style={[statStyles.barSegment, { flex: myPercent, backgroundColor: theme.deepRose, borderTopLeftRadius: 6, borderBottomLeftRadius: 6 }]} />
          <View style={[statStyles.barSegment, { flex: partnerPercent, backgroundColor: theme.deepLavender, borderTopRightRadius: 6, borderBottomRightRadius: 6 }]} />
        </View>
        <Text style={[statStyles.subtext, { color: theme.textLight }]}>You {myPercent}% 💬 {partnerName} {partnerPercent}%</Text>
      </View>

      <View style={[statStyles.card, { backgroundColor: theme.cardBg }]}>
        <Text style={[statStyles.label, { color: theme.textSecondary }]}>Most Active Hour</Text>
        <Text style={[statStyles.bigValue, { color: theme.text }]}>{formatHour(bestHour)} 🌙</Text>
      </View>

      <View style={[statStyles.card, { backgroundColor: theme.cardBg }]}>
        <Text style={[statStyles.label, { color: theme.textSecondary }]}>Chat Streak</Text>
        <Text style={[statStyles.bigValue, { color: theme.text }]}>{streak} days 🔥</Text>
      </View>

      {topWords.length > 0 && (
        <View style={[statStyles.card, { backgroundColor: theme.cardBg }]}>
          <Text style={[statStyles.label, { color: theme.textSecondary }]}>Most Used Words</Text>
          <View style={{ flexDirection: "row", gap: 8, flexWrap: "wrap" }}>
            {topWords.map(([word, count]) => (
              <View key={word} style={[statStyles.pill, { backgroundColor: theme.softPink }]}>
                <Text style={[statStyles.pillText, { color: theme.deepRose }]}>{word} ({count})</Text>
              </View>
            ))}
          </View>
        </View>
      )}

      {longestDay && (
        <View style={[statStyles.card, { backgroundColor: theme.cardBg }]}>
          <Text style={[statStyles.label, { color: theme.textSecondary }]}>Longest Chat Day</Text>
          <Text style={[statStyles.bigValue, { color: theme.text }]}>{longestCount} messages</Text>
          <Text style={[statStyles.subtext, { color: theme.textLight }]}>{longestDay}</Text>
        </View>
      )}
    </ScrollView>
  );
}

export default function ChatScreen() {
  const { user, userProfile, partnerProfile, coupleId } = useAuth();
  const { theme } = useTheme();
  const insets = useSafeAreaInsets();
  const [messages, setMessages] = useState<Message[]>([]);
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(true);
  const [partnerTyping, setPartnerTyping] = useState(false);
  const [partnerOnline, setPartnerOnline] = useState(false);
  const [partnerLastSeen, setPartnerLastSeen] = useState<number | null>(null);
  const [showStats, setShowStats] = useState(false);
  const flatListRef = useRef<FlatList>(null);
  const typingTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);

  const partnerId = partnerProfile?.uid;

  // Set online presence
  useEffect(() => {
    if (!user || !coupleId) return;
    const presenceRef = ref(db, `couples/${coupleId}/presence/${user.uid}`);
    set(presenceRef, "online");
    const disconnectRef = onDisconnect(presenceRef);
    disconnectRef.set("offline");

    const lastSeenRef = ref(db, `couples/${coupleId}/presence/${user.uid}_lastSeen`);
    const disconnectLastSeen = onDisconnect(lastSeenRef);
    disconnectLastSeen.set(Date.now());

    return () => {
      set(presenceRef, "offline");
      set(lastSeenRef, Date.now());
    };
  }, [user, coupleId]);

  // Listen to partner presence
  useEffect(() => {
    if (!coupleId || !partnerId) return;
    const presRef = ref(db, `couples/${coupleId}/presence/${partnerId}`);
    const lastSeenRef2 = ref(db, `couples/${coupleId}/presence/${partnerId}_lastSeen`);

    const unsub1 = onValue(presRef, (snap) => {
      setPartnerOnline(snap.val() === "online");
    });
    const unsub2 = onValue(lastSeenRef2, (snap) => {
      if (snap.exists()) setPartnerLastSeen(snap.val());
    });
    return () => { unsub1(); unsub2(); };
  }, [coupleId, partnerId]);

  // Listen to partner typing
  useEffect(() => {
    if (!coupleId || !partnerId) return;
    const typingRef = ref(db, `couples/${coupleId}/typing/${partnerId}`);
    const unsub = onValue(typingRef, (snap) => {
      setPartnerTyping(snap.val() === true);
    });
    return () => unsub();
  }, [coupleId, partnerId]);

  // Messages listener
  useEffect(() => {
    if (!coupleId) { setLoading(false); return; }
    const msgsRef = query(
      ref(db, `couples/${coupleId}/messages`),
      orderByChild("timestamp"),
      limitToLast(200)
    );
    const handler = onValue(msgsRef, (snap) => {
      if (!snap.exists()) { setMessages([]); setLoading(false); return; }
      const data = snap.val();
      const msgs: Message[] = Object.entries(data).map(([id, val]: any) => ({ id, ...val }));
      msgs.sort((a, b) => a.timestamp - b.timestamp);
      setMessages(msgs);
      setLoading(false);
    });
    return () => off(msgsRef, "value", handler);
  }, [coupleId]);

  // Mark messages as seen when screen is open
  useEffect(() => {
    if (!coupleId || !user || messages.length === 0) return;
    const unreadMsgs = messages.filter(
      m => m.senderId !== user.uid && m.status !== "seen"
    );
    if (unreadMsgs.length === 0) return;

    const updates: Record<string, string> = {};
    unreadMsgs.forEach(m => {
      updates[`couples/${coupleId}/messages/${m.id}/status`] = "seen";
    });
    update(ref(db), updates);
  }, [messages, coupleId, user]);

  // Mark messages as delivered when partner is online
  useEffect(() => {
    if (!coupleId || !user || !partnerOnline || messages.length === 0) return;
    const undelivered = messages.filter(
      m => m.senderId === user.uid && m.status === "sent"
    );
    if (undelivered.length === 0) return;

    const updates: Record<string, string> = {};
    undelivered.forEach(m => {
      updates[`couples/${coupleId}/messages/${m.id}/status`] = "delivered";
    });
    update(ref(db), updates);
  }, [messages, coupleId, user, partnerOnline]);

  // Handle typing
  const handleTextChange = (val: string) => {
    setText(val);
    if (!coupleId || !user) return;

    set(ref(db, `couples/${coupleId}/typing/${user.uid}`), true);

    if (typingTimeout.current) clearTimeout(typingTimeout.current);
    typingTimeout.current = setTimeout(() => {
      set(ref(db, `couples/${coupleId}/typing/${user.uid}`), false);
    }, 2000);
  };

  const sendMessage = useCallback(async () => {
    if (!text.trim() || !coupleId || !user || !userProfile) return;
    const msgText = text.trim();
    setText("");
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);

    set(ref(db, `couples/${coupleId}/typing/${user.uid}`), false);

    await push(ref(db, `couples/${coupleId}/messages`), {
      text: msgText,
      senderId: user.uid,
      senderName: userProfile.name,
      timestamp: Date.now(),
      status: "sent",
    });

    // Send push notification to partner
    if (partnerProfile?.uid) {
      const tokenSnap = await get(ref(db, `users/${partnerProfile.uid}/pushToken`));
      if (tokenSnap.exists()) {
        sendPushNotification(
          tokenSnap.val(),
          `💬 ${userProfile.name}`,
          msgText,
          { screen: "/(tabs)" }
        );
      }
    }
  }, [text, coupleId, user, userProfile, partnerProfile]);

  const renderItem = useCallback(({ item }: { item: Message }) => (
    <MessageBubble message={item} isMe={item.senderId === user?.uid} theme={theme} />
  ), [user?.uid, theme]);

  const partnerName = partnerProfile?.name || "your partner";

  const getLastSeenText = () => {
    if (partnerOnline) return "🟢 Online";
    if (partnerLastSeen) {
      const mins = Math.floor((Date.now() - partnerLastSeen) / 60000);
      if (mins < 1) return "Last seen just now";
      if (mins < 60) return `Last seen ${mins}m ago`;
      const hrs = Math.floor(mins / 60);
      if (hrs < 24) return `Last seen ${hrs}h ago`;
      return `Last seen ${Math.floor(hrs / 24)}d ago`;
    }
    return "Offline";
  };

  return (
    <View style={[styles.container, { backgroundColor: theme.offWhite }]}>
      <LinearGradient colors={[theme.headerGradientStart, theme.headerGradientEnd]} style={[styles.header, { paddingTop: insets.top + 12 }]}>
        <View style={styles.headerInner}>
          <View style={styles.headerAvatars}>
            <View style={[styles.headerAvatar, { backgroundColor: theme.deepRose }]}>
              <Text style={styles.headerAvatarText}>{(userProfile?.name || "?").charAt(0).toUpperCase()}</Text>
            </View>
            <View style={[styles.headerAvatar, { backgroundColor: theme.deepLavender, marginLeft: -10 }]}>
              <Text style={styles.headerAvatarText}>{partnerName.charAt(0).toUpperCase()}</Text>
            </View>
          </View>
          <View style={{ flex: 1 }}>
            <Text style={[styles.headerTitle, { color: theme.text }]}>Our Chat</Text>
            <Text style={[styles.headerSubtitle, { color: theme.textSecondary }]}>
              {partnerProfile ? getLastSeenText() : "Waiting for partner..."}
            </Text>
          </View>
          <Pressable onPress={() => setShowStats(true)} style={{ padding: 8, minHeight: MIN_BUTTON_HEIGHT, justifyContent: "center" }}>
            <Ionicons name="stats-chart-outline" size={20} color={theme.text} />
          </Pressable>
        </View>
      </LinearGradient>

      {loading ? (
        <View style={styles.centered}>
          <ActivityIndicator color={theme.deepRose} />
        </View>
      ) : !coupleId ? (
        <View style={styles.centered}>
          <Ionicons name="heart-outline" size={48} color={theme.textLight} />
          <Text style={[styles.emptyText, { color: theme.textLight }]}>Connect with your partner first</Text>
        </View>
      ) : (
        <KeyboardAvoidingView
          behavior={Platform.OS === "ios" ? "padding" : "height"}
          style={{ flex: 1 }}
          keyboardVerticalOffset={0}
        >
          <FlatList
            ref={flatListRef}
            data={messages}
            keyExtractor={(item) => item.id}
            renderItem={renderItem}
            contentContainerStyle={[styles.messageList, { paddingBottom: 16 }]}
            onContentSizeChange={() => flatListRef.current?.scrollToEnd({ animated: true })}
            onLayout={() => flatListRef.current?.scrollToEnd({ animated: false })}
            ListEmptyComponent={
              <View style={styles.emptyChat}>
                <Ionicons name="chatbubble-ellipses-outline" size={48} color={theme.textLight} />
                <Text style={[styles.emptyText, { color: theme.textLight }]}>Send your first message</Text>
              </View>
            }
            showsVerticalScrollIndicator={false}
          />

          {partnerTyping && (
            <View style={[styles.typingBar, { backgroundColor: theme.cardBg }]}>
              <TypingDots />
              <Text style={[styles.typingText, { color: theme.textSecondary }]}>{partnerName} is typing...</Text>
            </View>
          )}

          <View style={[styles.inputBar, { backgroundColor: theme.white, borderTopColor: theme.border, paddingBottom: Math.max(insets.bottom, 8) + 60 }]}>
            <View style={styles.inputWrapper}>
              <TextInput
                style={[styles.input, { backgroundColor: theme.inputBg, color: theme.text }]}
                placeholder="Say something..."
                placeholderTextColor={theme.textLight}
                value={text}
                onChangeText={handleTextChange}
                multiline
                maxLength={500}
              />
              <Pressable
                onPress={sendMessage}
                disabled={!text.trim()}
                style={({ pressed }) => [
                  styles.sendBtn,
                  { opacity: text.trim() ? (pressed ? 0.8 : 1) : 0.4, minHeight: MIN_BUTTON_HEIGHT },
                ]}
              >
                <LinearGradient colors={[theme.blush, theme.deepRose]} style={styles.sendBtnGrad}>
                  <Ionicons name="send" size={18} color="#fff" />
                </LinearGradient>
              </Pressable>
            </View>
          </View>
        </KeyboardAvoidingView>
      )}

      <Modal visible={showStats} animationType="slide" presentationStyle="pageSheet">
        <SafeAreaView style={[{ flex: 1, backgroundColor: theme.offWhite }]}>
          <View style={[styles.statsHeader, { backgroundColor: theme.cardBg, borderBottomColor: theme.border }]}>
            <Pressable onPress={() => setShowStats(false)} style={{ minHeight: MIN_BUTTON_HEIGHT, justifyContent: "center" }}>
              <Ionicons name="close" size={24} color={theme.text} />
            </Pressable>
            <Text style={[styles.statsTitle, { color: theme.text }]}>Chat Stats</Text>
            <View style={{ width: 24 }} />
          </View>
          <ChatStats messages={messages} userId={user?.uid || ""} partnerProfile={partnerProfile} theme={theme} />
        </SafeAreaView>
      </Modal>
    </View>
  );
}

const statStyles = StyleSheet.create({
  title: { fontFamily: "Nunito_800ExtraBold", fontSize: scaledFont(22) },
  card: { borderRadius: 16, padding: 16, gap: 8, shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.06, shadowRadius: 8, elevation: 2 },
  label: { fontFamily: "Nunito_600SemiBold", fontSize: scaledFont(12) },
  value: { fontFamily: "Nunito_700Bold", fontSize: scaledFont(18) },
  bigValue: { fontFamily: "Nunito_800ExtraBold", fontSize: scaledFont(24) },
  subtext: { fontFamily: "Nunito_400Regular", fontSize: scaledFont(12) },
  barContainer: { flexDirection: "row", height: 8, borderRadius: 6, overflow: "hidden" },
  barSegment: { height: "100%" },
  pill: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 20 },
  pillText: { fontFamily: "Nunito_600SemiBold", fontSize: scaledFont(13) },
});

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 20, paddingBottom: 16 },
  headerInner: { flexDirection: "row", alignItems: "center", gap: 14 },
  headerAvatars: { flexDirection: "row" },
  headerAvatar: { width: 38, height: 38, borderRadius: 19, alignItems: "center", justifyContent: "center", borderWidth: 2, borderColor: "#fff" },
  headerAvatarText: { fontFamily: "Nunito_700Bold", fontSize: scaledFont(15), color: "#fff" },
  headerTitle: { fontFamily: "Nunito_700Bold", fontSize: scaledFont(17) },
  headerSubtitle: { fontFamily: "Nunito_400Regular", fontSize: scaledFont(12) },
  centered: { flex: 1, alignItems: "center", justifyContent: "center", gap: 12 },
  emptyChat: { flex: 1, alignItems: "center", justifyContent: "center", paddingTop: 60, gap: 12 },
  emptyText: { fontFamily: "Nunito_400Regular", fontSize: scaledFont(15), textAlign: "center" },
  messageList: { paddingHorizontal: 16, paddingTop: 12, flexGrow: 1 },
  bubbleRow: { flexDirection: "row", alignItems: "flex-end", marginBottom: 12, gap: 8 },
  bubbleRowMe: { flexDirection: "row-reverse" },
  avatar: { width: 30, height: 30, borderRadius: 15, alignItems: "center", justifyContent: "center" },
  avatarText: { fontFamily: "Nunito_700Bold", fontSize: scaledFont(12) },
  bubbleGroup: { maxWidth: "72%", gap: 2 },
  senderName: { fontFamily: "Nunito_600SemiBold", fontSize: scaledFont(11), paddingLeft: 12 },
  bubble: { borderRadius: 18, paddingHorizontal: 14, paddingVertical: 10 },
  bubbleText: { fontFamily: "Nunito_400Regular", fontSize: scaledFont(15), lineHeight: 20 },
  timestamp: { fontFamily: "Nunito_400Regular", fontSize: scaledFont(10), paddingLeft: 12 },
  timestampMe: { textAlign: "right", paddingLeft: 0, paddingRight: 12 },
  typingBar: { flexDirection: "row", alignItems: "center", gap: 8, paddingHorizontal: 20, paddingVertical: 8 },
  typingText: { fontFamily: "Nunito_400Regular", fontSize: scaledFont(13) },
  inputBar: { paddingHorizontal: 12, paddingTop: 10, borderTopWidth: 1 },
  inputWrapper: { flexDirection: "row", alignItems: "center", gap: 8 },
  input: {
    flex: 1, borderRadius: 22, paddingHorizontal: 16, paddingVertical: 12,
    fontFamily: "Nunito_400Regular", fontSize: scaledFont(15), maxHeight: 100, minHeight: 44,
  },
  sendBtn: { justifyContent: "center", alignItems: "center" },
  sendBtnGrad: { width: 44, height: 44, borderRadius: 22, alignItems: "center", justifyContent: "center" },
  statsHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", padding: 20, borderBottomWidth: 1 },
  statsTitle: { fontFamily: "Nunito_700Bold", fontSize: scaledFont(17) },
});
