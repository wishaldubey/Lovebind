import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  Pressable,
  TextInput,
  Modal,
  Alert,
  ActivityIndicator,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  Dimensions,
} from "react-native";
import { SafeAreaView, useSafeAreaInsets } from "react-native-safe-area-context";
import { ref, push, remove, update, onValue, off } from "firebase/database";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { db } from "@/lib/firebase";
import { useAuth } from "@/context/AuthContext";
import { useTheme } from "@/context/ThemeContext";
import { scaledFont, MIN_BUTTON_HEIGHT } from "@/lib/responsive";

type NoteScope = "shared" | "mine";

interface Note {
  id: string;
  content: string;
  title: string;
  createdBy: string;
  createdByName: string;
  updatedAt: number;
}

function NoteCard({ note, isMe, onEdit, onDelete, theme }: { note: Note; isMe: boolean; onEdit: () => void; onDelete: () => void; theme: any }) {
  return (
    <Pressable onPress={onEdit} style={({ pressed }) => [noteStyles.card, { opacity: pressed ? 0.92 : 1 }]}>
      <LinearGradient
        colors={isMe ? [theme.softPink, theme.headerGradientEnd] : [theme.softLavender, theme.headerGradientEnd]}
        style={noteStyles.cardGrad}
      >
        <View style={noteStyles.cardHeader}>
          <Text style={[noteStyles.noteTitle, { color: theme.text }]} numberOfLines={1}>{note.title || "Untitled"}</Text>
          <View style={noteStyles.cardActions}>
            <Pressable onPress={onDelete} hitSlop={8} style={{ minHeight: MIN_BUTTON_HEIGHT, justifyContent: "center" }}>
              <Ionicons name="trash-outline" size={15} color={theme.textLight} />
            </Pressable>
          </View>
        </View>
        <Text style={[noteStyles.noteContent, { color: theme.textSecondary }]} numberOfLines={3}>{note.content}</Text>
        <View style={noteStyles.cardFooter}>
          <Text style={[noteStyles.byText, { color: theme.textLight }]}>{isMe ? "You" : note.createdByName}</Text>
          <Text style={[noteStyles.timeText, { color: theme.textLight }]}>
            {new Date(note.updatedAt).toLocaleDateString("en-US", { month: "short", day: "numeric" })}
          </Text>
        </View>
      </LinearGradient>
    </Pressable>
  );
}

export default function NotesScreen() {
  const { user, userProfile, coupleId } = useAuth();
  const { theme } = useTheme();
  const insets = useSafeAreaInsets();
  const [scope, setScope] = useState<NoteScope>("shared");
  const [sharedNotes, setSharedNotes] = useState<Note[]>([]);
  const [myNotes, setMyNotes] = useState<Note[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalVisible, setModalVisible] = useState(false);
  const [editNote, setEditNote] = useState<Note | null>(null);
  const [noteTitle, setNoteTitle] = useState("");
  const [noteContent, setNoteContent] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!coupleId || !user) { setLoading(false); return; }
    const sharedRef = ref(db, `couples/${coupleId}/notes/shared`);
    const myRef = ref(db, `couples/${coupleId}/notes/${user.uid}`);

    const sharedHandler = onValue(sharedRef, (snap) => {
      if (!snap.exists()) { setSharedNotes([]); return; }
      const list: Note[] = Object.entries(snap.val()).map(([id, val]: any) => ({ id, ...val }));
      list.sort((a, b) => b.updatedAt - a.updatedAt);
      setSharedNotes(list);
      setLoading(false);
    });
    const myHandler = onValue(myRef, (snap) => {
      if (!snap.exists()) { setMyNotes([]); return; }
      const list: Note[] = Object.entries(snap.val()).map(([id, val]: any) => ({ id, ...val }));
      list.sort((a, b) => b.updatedAt - a.updatedAt);
      setMyNotes(list);
      setLoading(false);
    });
    setLoading(false);
    return () => {
      off(sharedRef, "value", sharedHandler);
      off(myRef, "value", myHandler);
    };
  }, [coupleId, user]);

  const openAdd = () => { setEditNote(null); setNoteTitle(""); setNoteContent(""); setModalVisible(true); };
  const openEdit = (note: Note) => { setEditNote(note); setNoteTitle(note.title); setNoteContent(note.content); setModalVisible(true); };

  const handleSave = async () => {
    if (!noteContent.trim()) { Alert.alert("Empty note", "Write something first."); return; }
    if (!coupleId || !user || !userProfile) return;
    setSaving(true);
    const path = scope === "shared" ? `couples/${coupleId}/notes/shared` : `couples/${coupleId}/notes/${user.uid}`;
    const noteData = {
      title: noteTitle.trim() || "Untitled",
      content: noteContent.trim(),
      createdBy: user.uid,
      createdByName: userProfile.name,
      updatedAt: Date.now(),
    };
    if (editNote) {
      await update(ref(db, `${path}/${editNote.id}`), noteData);
    } else {
      await push(ref(db, path), noteData);
    }
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setModalVisible(false);
    setSaving(false);
  };

  const handleDelete = (noteId: string) => {
    Alert.alert("Delete note?", "This cannot be undone.", [
      { text: "Cancel", style: "cancel" },
      { text: "Delete", style: "destructive", onPress: async () => {
        const path = scope === "shared" ? `couples/${coupleId}/notes/shared/${noteId}` : `couples/${coupleId}/notes/${user?.uid}/${noteId}`;
        await remove(ref(db, path));
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
      }},
    ]);
  };

  const notes = scope === "shared" ? sharedNotes : myNotes;

  return (
    <View style={[styles.container, { backgroundColor: theme.offWhite }]}>
      <LinearGradient colors={[theme.headerGradientStart, theme.headerGradientEnd]} style={[styles.header, { paddingTop: insets.top + 12 }]}>
        <View style={styles.headerRow}>
          <Text style={[styles.headerTitle, { color: theme.text }]}>Notes</Text>
          <Pressable onPress={openAdd} style={({ pressed }) => [styles.addBtn, { opacity: pressed ? 0.85 : 1 }]}>
            <LinearGradient colors={[theme.lavender, theme.deepLavender]} style={styles.addBtnGrad}>
              <Ionicons name="add" size={22} color="#fff" />
            </LinearGradient>
          </Pressable>
        </View>
        <View style={[styles.toggle, { backgroundColor: theme.cardBg }]}>
          <Pressable onPress={() => setScope("shared")} style={[styles.toggleBtn, scope === "shared" && { backgroundColor: theme.softPink }, { minHeight: MIN_BUTTON_HEIGHT }]}>
            <Ionicons name="people-outline" size={14} color={scope === "shared" ? theme.deepRose : theme.textSecondary} />
            <Text style={[styles.toggleText, { color: scope === "shared" ? theme.deepRose : theme.textSecondary }]}>Shared</Text>
          </Pressable>
          <Pressable onPress={() => setScope("mine")} style={[styles.toggleBtn, scope === "mine" && { backgroundColor: theme.softPink }, { minHeight: MIN_BUTTON_HEIGHT }]}>
            <Ionicons name="person-outline" size={14} color={scope === "mine" ? theme.deepRose : theme.textSecondary} />
            <Text style={[styles.toggleText, { color: scope === "mine" ? theme.deepRose : theme.textSecondary }]}>My Notes</Text>
          </Pressable>
        </View>
      </LinearGradient>

      {loading ? (
        <View style={styles.centered}><ActivityIndicator color={theme.deepRose} /></View>
      ) : (
        <FlatList
          data={notes}
          keyExtractor={(item) => item.id}
          numColumns={2}
          columnWrapperStyle={{ gap: 12 }}
          renderItem={({ item }) => (
            <NoteCard note={item} isMe={item.createdBy === user?.uid} onEdit={() => openEdit(item)} onDelete={() => handleDelete(item.id)} theme={theme} />
          )}
          contentContainerStyle={[styles.list, { paddingBottom: insets.bottom + 90 }]}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={
            <View style={styles.empty}>
              <Ionicons name="document-text-outline" size={56} color={theme.textLight} />
              <Text style={[styles.emptyTitle, { color: theme.text }]}>No {scope === "shared" ? "shared" : "personal"} notes</Text>
              <Text style={[styles.emptyText, { color: theme.textLight }]}>Tap + to add one</Text>
            </View>
          }
        />
      )}

      <Modal visible={modalVisible} animationType="slide" presentationStyle="pageSheet">
        <SafeAreaView style={[{ flex: 1, backgroundColor: theme.cardBg }]}>
          <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : "height"} style={{ flex: 1 }}>
            <View style={[styles.modalHeader, { borderBottomColor: theme.border }]}>
              <Pressable onPress={() => setModalVisible(false)} style={{ minHeight: MIN_BUTTON_HEIGHT, justifyContent: "center" }}>
                <Ionicons name="close" size={24} color={theme.text} />
              </Pressable>
              <Text style={[styles.modalTitle, { color: theme.text }]}>{editNote ? "Edit Note" : "New Note"}</Text>
              <Pressable onPress={handleSave} disabled={saving} style={{ minHeight: MIN_BUTTON_HEIGHT, justifyContent: "center" }}>
                {saving ? <ActivityIndicator size="small" color={theme.deepLavender} /> : (
                  <Text style={[styles.saveText, { color: theme.deepLavender }]}>Save</Text>
                )}
              </Pressable>
            </View>
            <ScrollView contentContainerStyle={styles.modalContent} keyboardShouldPersistTaps="handled">
              <TextInput
                style={[styles.titleInput, { color: theme.text, borderBottomColor: theme.border }]}
                placeholder="Note title..."
                placeholderTextColor={theme.textLight}
                value={noteTitle}
                onChangeText={setNoteTitle}
              />
              <TextInput
                style={[styles.contentInput, { color: theme.text }]}
                placeholder="Write your note here..."
                placeholderTextColor={theme.textLight}
                value={noteContent}
                onChangeText={setNoteContent}
                multiline
                textAlignVertical="top"
                autoFocus={!editNote}
              />
            </ScrollView>
          </KeyboardAvoidingView>
        </SafeAreaView>
      </Modal>
    </View>
  );
}

const noteStyles = StyleSheet.create({
  card: { flex: 1, borderRadius: 14, overflow: "hidden", shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.06, shadowRadius: 8, elevation: 2 },
  cardGrad: { padding: 14, gap: 6 },
  cardHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start" },
  noteTitle: { fontFamily: "Nunito_700Bold", fontSize: scaledFont(14), flex: 1, marginRight: 8 },
  cardActions: { flexDirection: "row", gap: 10 },
  noteContent: { fontFamily: "Nunito_400Regular", fontSize: scaledFont(13), lineHeight: 18 },
  cardFooter: { flexDirection: "row", justifyContent: "space-between", marginTop: 4 },
  byText: { fontFamily: "Nunito_600SemiBold", fontSize: scaledFont(11) },
  timeText: { fontFamily: "Nunito_400Regular", fontSize: scaledFont(11) },
});

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 20, paddingBottom: 16, gap: 14 },
  headerRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  headerTitle: { fontFamily: "Nunito_800ExtraBold", fontSize: scaledFont(24) },
  addBtn: { borderRadius: 22, overflow: "hidden" },
  addBtnGrad: { width: 44, height: 44, alignItems: "center", justifyContent: "center", minHeight: MIN_BUTTON_HEIGHT },
  toggle: { flexDirection: "row", borderRadius: 12, padding: 4, shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 6, elevation: 1 },
  toggleBtn: { flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6, paddingVertical: 8, borderRadius: 10 },
  toggleText: { fontFamily: "Nunito_600SemiBold", fontSize: scaledFont(13) },
  centered: { flex: 1, alignItems: "center", justifyContent: "center" },
  list: { padding: 16, gap: 12 },
  empty: { alignItems: "center", paddingTop: 60, gap: 10 },
  emptyTitle: { fontFamily: "Nunito_700Bold", fontSize: scaledFont(18) },
  emptyText: { fontFamily: "Nunito_400Regular", fontSize: scaledFont(14) },
  modalHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", padding: 20, borderBottomWidth: 1 },
  modalTitle: { fontFamily: "Nunito_700Bold", fontSize: scaledFont(17) },
  saveText: { fontFamily: "Nunito_700Bold", fontSize: scaledFont(16) },
  modalContent: { padding: 20, flexGrow: 1, gap: 12 },
  titleInput: { fontFamily: "Nunito_700Bold", fontSize: scaledFont(20), borderBottomWidth: 1, paddingBottom: 12 },
  contentInput: { fontFamily: "Nunito_400Regular", fontSize: scaledFont(16), flex: 1, minHeight: 300, lineHeight: 24 },
});
