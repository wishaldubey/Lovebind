import React, { useState, useEffect, useCallback } from "react";
import {
  View, Text, StyleSheet, Pressable, FlatList, TextInput,
  Modal, KeyboardAvoidingView, Platform, Alert, ScrollView, Image,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import * as ImagePicker from "expo-image-picker";
import { ref, push, onValue, remove } from "firebase/database";
import { useAuth } from "@/context/AuthContext";
import { useTheme } from "@/context/ThemeContext";
import { db } from "@/lib/firebase";
import { scaledFont, wp, MIN_BUTTON_HEIGHT } from "@/lib/responsive";

interface Trip {
  id: string;
  title: string;
  location: string;
  date: string;
  description?: string;
  notes?: string;
  rating?: number;
  photo?: string; // base64
  createdBy: string;
  createdAt: number;
}

export default function TripsScreen() {
  const { user, coupleId, userProfile } = useAuth();
  const { theme } = useTheme();
  const insets = useSafeAreaInsets();
  const [trips, setTrips] = useState<Trip[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [selectedTrip, setSelectedTrip] = useState<Trip | null>(null);
  const [title, setTitle] = useState("");
  const [location, setLocation] = useState("");
  const [date, setDate] = useState("");
  const [description, setDescription] = useState("");
  const [notes, setNotes] = useState("");
  const [rating, setRating] = useState(0);
  const [photo, setPhoto] = useState<string | null>(null);

  useEffect(() => {
    if (!coupleId) return;
    const tripsRef = ref(db, `couples/${coupleId}/trips`);
    const unsub = onValue(tripsRef, (snap) => {
      if (!snap.exists()) { setTrips([]); return; }
      const data = snap.val();
      const list: Trip[] = Object.entries(data).map(([id, val]: any) => ({ id, ...val }));
      list.sort((a, b) => b.createdAt - a.createdAt);
      setTrips(list);
    });
    return () => unsub();
  }, [coupleId]);

  const pickImage = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== "granted") {
      Alert.alert("Permission needed", "Allow photo access to add trip photos.");
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ["images"],
      allowsEditing: true,
      aspect: [16, 9],
      quality: 0.5,
      base64: true,
    });
    if (!result.canceled && result.assets[0].base64) {
      setPhoto(`data:image/jpeg;base64,${result.assets[0].base64}`);
    }
  };

  const takePhoto = async () => {
    const { status } = await ImagePicker.requestCameraPermissionsAsync();
    if (status !== "granted") {
      Alert.alert("Permission needed", "Allow camera access to take trip photos.");
      return;
    }
    const result = await ImagePicker.launchCameraAsync({
      allowsEditing: true,
      aspect: [16, 9],
      quality: 0.5,
      base64: true,
    });
    if (!result.canceled && result.assets[0].base64) {
      setPhoto(`data:image/jpeg;base64,${result.assets[0].base64}`);
    }
  };

  const showPhotoOptions = () => {
    Alert.alert("Add Photo", "Choose a photo source", [
      { text: "Camera", onPress: takePhoto },
      { text: "Gallery", onPress: pickImage },
      { text: "Cancel", style: "cancel" },
    ]);
  };

  const handleAdd = async () => {
    if (!title.trim() || !location.trim() || !coupleId || !user) return;
    await push(ref(db, `couples/${coupleId}/trips`), {
      title: title.trim(),
      location: location.trim(),
      date: date.trim() || new Date().toLocaleDateString(),
      description: description.trim(),
      notes: notes.trim(),
      rating,
      photo: photo || null,
      createdBy: user.uid,
      createdAt: Date.now(),
    });
    resetForm();
    setShowAdd(false);
  };

  const handleDelete = (trip: Trip) => {
    Alert.alert("Delete Trip", "Remove this trip memory?", [
      { text: "Cancel", style: "cancel" },
      { text: "Delete", style: "destructive", onPress: () => {
        if (coupleId) remove(ref(db, `couples/${coupleId}/trips/${trip.id}`));
        setSelectedTrip(null);
      }},
    ]);
  };

  const resetForm = () => {
    setTitle(""); setLocation(""); setDate(""); setDescription(""); setNotes(""); setRating(0); setPhoto(null);
  };

  const getEmoji = (loc?: string) => {
    const l = (loc || "").toLowerCase();
    if (l.includes("beach") || l.includes("sea") || l.includes("ocean")) return "🏖️";
    if (l.includes("mountain") || l.includes("hill")) return "⛰️";
    if (l.includes("city") || l.includes("town")) return "🏙️";
    if (l.includes("lake") || l.includes("river")) return "🌊";
    if (l.includes("forest") || l.includes("park")) return "🌲";
    return "✈️";
  };

  const renderTrip = useCallback(({ item }: { item: Trip }) => (
    <Pressable
      onPress={() => setSelectedTrip(item)}
      style={({ pressed }) => [
        styles.tripCard,
        { backgroundColor: theme.cardBg, borderColor: theme.border, opacity: pressed ? 0.92 : 1 },
      ]}
    >
      {/* Trip photo thumbnail */}
      {item.photo && (
        <Image source={{ uri: item.photo }} style={styles.tripPhoto} resizeMode="cover" />
      )}
      <View style={styles.tripCardRow}>
        <View style={[styles.tripEmoji, { backgroundColor: theme.inputBg }]}>
          <Text style={{ fontSize: 24 }}>{getEmoji(item.location)}</Text>
        </View>
        <View style={{ flex: 1 }}>
          <Text style={[styles.tripTitle, { color: theme.text }]} numberOfLines={1}>{item.title}</Text>
          <View style={styles.tripMeta}>
            <Ionicons name="location-outline" size={13} color={theme.textSecondary} />
            <Text style={[styles.tripLocation, { color: theme.textSecondary }]} numberOfLines={1}>{item.location}</Text>
          </View>
          <View style={styles.tripMeta}>
            <Ionicons name="calendar-outline" size={13} color={theme.textLight} />
            <Text style={[styles.tripDate, { color: theme.textLight }]}>{item.date}</Text>
          </View>
        </View>
        <View style={styles.tripArrow}>
          {item.rating ? (
            <Text style={{ fontSize: 10 }}>{"⭐".repeat(Math.min(item.rating, 5))}</Text>
          ) : null}
          <Ionicons name="chevron-forward" size={18} color={theme.textLight} />
        </View>
      </View>
    </Pressable>
  ), [theme]);

  return (
    <View style={[styles.container, { backgroundColor: theme.background }]}>
      <LinearGradient colors={[theme.headerGradientStart, theme.headerGradientEnd]} style={[styles.header, { paddingTop: insets.top + 12 }]}>
        <Text style={[styles.headerTitle, { color: theme.text }]}>✈️ Trip Memories</Text>
        <Text style={[styles.headerSub, { color: theme.textSecondary }]}>{trips.length} memories saved</Text>
      </LinearGradient>

      <FlatList
        data={trips}
        keyExtractor={(item) => item.id}
        renderItem={renderTrip}
        contentContainerStyle={[styles.list, { paddingBottom: insets.bottom + 80 }]}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <Ionicons name="airplane-outline" size={48} color={theme.textLight} />
            <Text style={[styles.emptyText, { color: theme.textLight }]}>No trip memories yet</Text>
            <Text style={[styles.emptySubText, { color: theme.textLight }]}>Add your first adventure together!</Text>
          </View>
        }
      />

      {/* FAB */}
      <Pressable onPress={() => { resetForm(); setShowAdd(true); }} style={styles.fab}>
        <LinearGradient colors={[theme.blush, theme.deepRose]} style={styles.fabGrad}>
          <Ionicons name="add" size={28} color="#fff" />
        </LinearGradient>
      </Pressable>

      {/* Add Trip Modal */}
      <Modal visible={showAdd} animationType="slide" presentationStyle="pageSheet">
        <SafeAreaView style={[{ flex: 1, backgroundColor: theme.offWhite }]}>
          <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : "height"} style={{ flex: 1 }}>
            <View style={[styles.modalHeader, { backgroundColor: theme.cardBg, borderBottomColor: theme.border }]}>
              <Pressable onPress={() => setShowAdd(false)} style={{ minHeight: MIN_BUTTON_HEIGHT, justifyContent: "center" }}>
                <Text style={[styles.modalCancel, { color: theme.textSecondary }]}>Cancel</Text>
              </Pressable>
              <Text style={[styles.modalTitle, { color: theme.text }]}>New Trip</Text>
              <Pressable onPress={handleAdd} style={{ minHeight: MIN_BUTTON_HEIGHT, justifyContent: "center" }}>
                <Text style={[styles.modalSave, { color: theme.deepRose }]}>Save</Text>
              </Pressable>
            </View>
            <ScrollView contentContainerStyle={styles.formContent} keyboardShouldPersistTaps="handled">
              {/* Photo picker */}
              <Pressable onPress={showPhotoOptions} style={[styles.photoPicker, { backgroundColor: theme.cardBg, borderColor: theme.border }]}>
                {photo ? (
                  <Image source={{ uri: photo }} style={styles.photoPreview} resizeMode="cover" />
                ) : (
                  <View style={styles.photoPlaceholder}>
                    <Ionicons name="camera-outline" size={32} color={theme.textLight} />
                    <Text style={[styles.photoText, { color: theme.textSecondary }]}>Add a photo</Text>
                  </View>
                )}
              </Pressable>
              {photo && (
                <Pressable onPress={() => setPhoto(null)} style={{ alignSelf: "center" }}>
                  <Text style={[styles.removePhotoText, { color: theme.deepRose }]}>Remove photo</Text>
                </Pressable>
              )}

              <Text style={[styles.label, { color: theme.text }]}>Title *</Text>
              <TextInput style={[styles.formInput, { backgroundColor: theme.cardBg, color: theme.text, borderColor: theme.border }]} placeholder="e.g. Goa Beach Trip" placeholderTextColor={theme.textLight} value={title} onChangeText={setTitle} />

              <Text style={[styles.label, { color: theme.text }]}>Location *</Text>
              <TextInput style={[styles.formInput, { backgroundColor: theme.cardBg, color: theme.text, borderColor: theme.border }]} placeholder="e.g. Goa, India" placeholderTextColor={theme.textLight} value={location} onChangeText={setLocation} />

              <Text style={[styles.label, { color: theme.text }]}>Date</Text>
              <TextInput style={[styles.formInput, { backgroundColor: theme.cardBg, color: theme.text, borderColor: theme.border }]} placeholder="e.g. Jan 2024" placeholderTextColor={theme.textLight} value={date} onChangeText={setDate} />

              <Text style={[styles.label, { color: theme.text }]}>Description</Text>
              <TextInput style={[styles.formInput, styles.textArea, { backgroundColor: theme.cardBg, color: theme.text, borderColor: theme.border }]} placeholder="What made this trip special?" placeholderTextColor={theme.textLight} value={description} onChangeText={setDescription} multiline numberOfLines={3} />

              <Text style={[styles.label, { color: theme.text }]}>Notes</Text>
              <TextInput style={[styles.formInput, styles.textArea, { backgroundColor: theme.cardBg, color: theme.text, borderColor: theme.border }]} placeholder="Funny moments, tips, things to remember..." placeholderTextColor={theme.textLight} value={notes} onChangeText={setNotes} multiline numberOfLines={2} />

              <Text style={[styles.label, { color: theme.text }]}>Rating</Text>
              <View style={styles.starsRow}>
                {[1, 2, 3, 4, 5].map((n) => (
                  <Pressable key={`star-${n}`} onPress={() => setRating(n)} style={{ padding: 4 }}>
                    <Ionicons name={n <= rating ? "star" : "star-outline"} size={28} color={n <= rating ? "#F5A623" : theme.textLight} />
                  </Pressable>
                ))}
              </View>
            </ScrollView>
          </KeyboardAvoidingView>
        </SafeAreaView>
      </Modal>

      {/* Trip Detail Modal */}
      <Modal visible={!!selectedTrip} animationType="slide" presentationStyle="pageSheet">
        <SafeAreaView style={[{ flex: 1, backgroundColor: theme.offWhite }]}>
          {selectedTrip && (
            <>
              <View style={[styles.modalHeader, { backgroundColor: theme.cardBg, borderBottomColor: theme.border }]}>
                <Pressable onPress={() => setSelectedTrip(null)} style={{ minHeight: MIN_BUTTON_HEIGHT, justifyContent: "center" }}>
                  <Ionicons name="chevron-back" size={24} color={theme.text} />
                </Pressable>
                <Text style={[styles.modalTitle, { color: theme.text }]} numberOfLines={1}>{selectedTrip.title}</Text>
                <Pressable onPress={() => handleDelete(selectedTrip)} style={{ minHeight: MIN_BUTTON_HEIGHT, justifyContent: "center" }}>
                  <Ionicons name="trash-outline" size={20} color="#E74C3C" />
                </Pressable>
              </View>
              <ScrollView contentContainerStyle={styles.detailContent}>
                {/* Trip photo */}
                {selectedTrip.photo && (
                  <Image source={{ uri: selectedTrip.photo }} style={styles.detailPhoto} resizeMode="cover" />
                )}

                <View style={[styles.detailCard, { backgroundColor: theme.cardBg, borderColor: theme.border }]}>
                  {!selectedTrip.photo && (
                    <View style={styles.detailEmojiWrap}>
                      <Text style={{ fontSize: 48 }}>{getEmoji(selectedTrip.location)}</Text>
                    </View>
                  )}
                  <Text style={[styles.detailTitle, { color: theme.text }]}>{selectedTrip.title}</Text>

                  <View style={styles.detailInfoRow}>
                    <Ionicons name="location" size={16} color={theme.deepRose} />
                    <Text style={[styles.detailInfo, { color: theme.textSecondary }]}>{selectedTrip.location}</Text>
                  </View>
                  <View style={styles.detailInfoRow}>
                    <Ionicons name="calendar" size={16} color={theme.deepLavender} />
                    <Text style={[styles.detailInfo, { color: theme.textSecondary }]}>{selectedTrip.date}</Text>
                  </View>

                  {selectedTrip.rating ? (
                    <View style={styles.detailRating}>
                      {[1, 2, 3, 4, 5].map((n) => (
                        <Ionicons key={`dstar-${n}`} name={n <= (selectedTrip.rating || 0) ? "star" : "star-outline"} size={22} color={n <= (selectedTrip.rating || 0) ? "#F5A623" : theme.textLight} />
                      ))}
                    </View>
                  ) : null}
                </View>

                {selectedTrip.description ? (
                  <View style={[styles.detailSection, { backgroundColor: theme.cardBg, borderColor: theme.border }]}>
                    <Text style={[styles.sectionTitle, { color: theme.text }]}>✨ About this trip</Text>
                    <Text style={[styles.sectionBody, { color: theme.textSecondary }]}>{selectedTrip.description}</Text>
                  </View>
                ) : null}

                {selectedTrip.notes ? (
                  <View style={[styles.detailSection, { backgroundColor: theme.cardBg, borderColor: theme.border }]}>
                    <Text style={[styles.sectionTitle, { color: theme.text }]}>📝 Notes</Text>
                    <Text style={[styles.sectionBody, { color: theme.textSecondary }]}>{selectedTrip.notes}</Text>
                  </View>
                ) : null}
              </ScrollView>
            </>
          )}
        </SafeAreaView>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 20, paddingBottom: 14, alignItems: "center" },
  headerTitle: { fontFamily: "Nunito_700Bold", fontSize: scaledFont(20) },
  headerSub: { fontFamily: "Nunito_400Regular", fontSize: scaledFont(13), marginTop: 2 },
  list: { paddingHorizontal: 16, paddingTop: 12 },
  emptyState: { alignItems: "center", justifyContent: "center", paddingTop: 80, gap: 8 },
  emptyText: { fontFamily: "Nunito_600SemiBold", fontSize: scaledFont(16) },
  emptySubText: { fontFamily: "Nunito_400Regular", fontSize: scaledFont(13) },
  tripCard: {
    borderRadius: 16, marginBottom: 12, borderWidth: 1, overflow: "hidden",
    shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.05, shadowRadius: 8, elevation: 2,
  },
  tripPhoto: { width: "100%", height: 140, borderTopLeftRadius: 16, borderTopRightRadius: 16 },
  tripCardRow: { flexDirection: "row", alignItems: "center", gap: 14, padding: 16 },
  tripEmoji: { width: 48, height: 48, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  tripTitle: { fontFamily: "Nunito_700Bold", fontSize: scaledFont(16), marginBottom: 4 },
  tripMeta: { flexDirection: "row", alignItems: "center", gap: 4, marginBottom: 2 },
  tripLocation: { fontFamily: "Nunito_400Regular", fontSize: scaledFont(13) },
  tripDate: { fontFamily: "Nunito_400Regular", fontSize: scaledFont(12) },
  tripArrow: { alignItems: "flex-end", gap: 4 },
  fab: {
    position: "absolute", bottom: 100, right: 20,
    shadowColor: "#000", shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.2, shadowRadius: 10, elevation: 6,
  },
  fabGrad: { width: 56, height: 56, borderRadius: 28, alignItems: "center", justifyContent: "center" },
  modalHeader: {
    flexDirection: "row", justifyContent: "space-between", alignItems: "center",
    paddingHorizontal: 20, paddingVertical: 8, borderBottomWidth: 1,
  },
  modalCancel: { fontFamily: "Nunito_600SemiBold", fontSize: scaledFont(15) },
  modalTitle: { fontFamily: "Nunito_700Bold", fontSize: scaledFont(17), flex: 1, textAlign: "center" },
  modalSave: { fontFamily: "Nunito_700Bold", fontSize: scaledFont(15) },
  formContent: { paddingHorizontal: 20, paddingTop: 20, paddingBottom: 40, gap: 4 },
  photoPicker: {
    borderRadius: 16, borderWidth: 1.5, borderStyle: "dashed", overflow: "hidden",
    marginBottom: 8,
  },
  photoPreview: { width: "100%", height: 180, borderRadius: 14 },
  photoPlaceholder: { alignItems: "center", justifyContent: "center", paddingVertical: 36, gap: 8 },
  photoText: { fontFamily: "Nunito_600SemiBold", fontSize: scaledFont(14) },
  removePhotoText: { fontFamily: "Nunito_600SemiBold", fontSize: scaledFont(13), marginBottom: 8 },
  label: { fontFamily: "Nunito_600SemiBold", fontSize: scaledFont(13), marginTop: 12, marginBottom: 6 },
  formInput: {
    borderWidth: 1, borderRadius: 14, paddingHorizontal: 16, paddingVertical: 12,
    fontFamily: "Nunito_400Regular", fontSize: scaledFont(15),
  },
  textArea: { minHeight: 80, textAlignVertical: "top" },
  starsRow: { flexDirection: "row", gap: 4, marginTop: 4 },
  detailContent: { paddingHorizontal: 20, paddingTop: 0, paddingBottom: 40, gap: 16 },
  detailPhoto: { width: "100%", height: 220, borderRadius: 16, marginTop: 16 },
  detailCard: {
    borderRadius: 20, padding: 24, alignItems: "center", borderWidth: 1, gap: 8,
  },
  detailEmojiWrap: { marginBottom: 8 },
  detailTitle: { fontFamily: "Nunito_800ExtraBold", fontSize: scaledFont(22), textAlign: "center" },
  detailInfoRow: { flexDirection: "row", alignItems: "center", gap: 6, marginTop: 4 },
  detailInfo: { fontFamily: "Nunito_400Regular", fontSize: scaledFont(14) },
  detailRating: { flexDirection: "row", gap: 4, marginTop: 8 },
  detailSection: {
    borderRadius: 16, padding: 20, borderWidth: 1,
  },
  sectionTitle: { fontFamily: "Nunito_700Bold", fontSize: scaledFont(15), marginBottom: 8 },
  sectionBody: { fontFamily: "Nunito_400Regular", fontSize: scaledFont(14), lineHeight: 22 },
});
