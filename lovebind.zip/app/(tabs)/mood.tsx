import React, { useState, useEffect, useCallback } from "react";
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  ActivityIndicator,
  ScrollView,
  Dimensions,
} from "react-native";
import { SafeAreaView, useSafeAreaInsets } from "react-native-safe-area-context";
import { ref, set, get, push, onValue, off } from "firebase/database";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import Animated, { useSharedValue, useAnimatedStyle, withTiming, withSequence, runOnJS } from "react-native-reanimated";
import { db } from "@/lib/firebase";
import { useAuth } from "@/context/AuthContext";
import { useTheme } from "@/context/ThemeContext";
import { scaledFont, MIN_BUTTON_HEIGHT } from "@/lib/responsive";
import { sendPushNotification } from "@/lib/notifications";

const { width: SCREEN_WIDTH } = Dimensions.get("window");

interface MoodOption {
  key: string;
  label: string;
  icon: keyof typeof Ionicons.glyphMap;
  color: string;
  bg: string;
  score: number;
}

const MOODS: MoodOption[] = [
  { key: "sad", label: "Sad", icon: "rainy-outline", color: "#5B8DEF", bg: "#EAF2FF", score: 1 },
  { key: "anxious", label: "Anxious", icon: "thunderstorm-outline", color: "#F0A500", bg: "#FFF4E0", score: 2 },
  { key: "tired", label: "Tired", icon: "moon-outline", color: "#8A7090", bg: "#F5EDFF", score: 3 },
  { key: "neutral", label: "Neutral", icon: "ellipse-outline", color: "#999", bg: "#f0f0f0", score: 4 },
  { key: "happy", label: "Happy", icon: "sunny-outline", color: "#F5A623", bg: "#FFF8E7", score: 5 },
  { key: "loved", label: "Loved", icon: "heart", color: "#FF6B9D", bg: "#FFF0F5", score: 6 },
  { key: "excited", label: "Excited", icon: "flash-outline", color: "#7B61FF", bg: "#F0EDFF", score: 7 },
];

const QUICK_MESSAGES = [
  "I miss you 💔",
  "I love you ❤️",
  "Thinking of you 🌸",
  "Good morning ☀️",
  "Good night 🌙",
  "Sending hugs 🤗",
  "You mean everything to me 💫",
  "Can't wait to see you ✈️",
];

function getMoodOption(key: string): MoodOption | undefined {
  return MOODS.find((m) => m.key === key);
}

function getMoodLabel(score: number): string {
  const mood = MOODS.find(m => m.score === score);
  return mood?.label || "Unknown";
}

function getMoodEmoji(score: number): string {
  const emojis: Record<number, string> = { 1: "😢", 2: "😰", 3: "😴", 4: "😐", 5: "😊", 6: "🥰", 7: "🤩" };
  return emojis[score] || "😐";
}

function MoodSelector({ selected, onSelect, theme }: { selected: string; onSelect: (key: string) => void; theme: any }) {
  return (
    <View style={moodStyles.grid}>
      {MOODS.map((mood) => {
        const isSelected = selected === mood.key;
        return (
          <Pressable
            key={mood.key}
            onPress={() => {
              Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
              onSelect(mood.key);
            }}
            style={({ pressed }) => [
              moodStyles.moodBtn,
              { backgroundColor: mood.bg, opacity: pressed ? 0.85 : 1, minHeight: MIN_BUTTON_HEIGHT },
              isSelected && { borderWidth: 2, borderColor: mood.color },
            ]}
          >
            <Ionicons name={mood.icon} size={28} color={mood.color} />
            <Text style={[moodStyles.moodLabel, { color: mood.color }]}>{mood.label}</Text>
            {isSelected && (
              <View style={[moodStyles.checkmark, { backgroundColor: mood.color }]}>
                <Ionicons name="checkmark" size={10} color="#fff" />
              </View>
            )}
          </Pressable>
        );
      })}
    </View>
  );
}

function HeartConfirmation({ visible }: { visible: boolean }) {
  const scale = useSharedValue(0);
  const opacity = useSharedValue(0);

  useEffect(() => {
    if (visible) {
      scale.value = withSequence(
        withTiming(1.3, { duration: 200 }),
        withTiming(1, { duration: 150 }),
        withTiming(1, { duration: 500 }),
        withTiming(0, { duration: 300 })
      );
      opacity.value = withSequence(
        withTiming(1, { duration: 200 }),
        withTiming(1, { duration: 450 }),
        withTiming(0, { duration: 300 })
      );
    }
  }, [visible]);

  const animStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
    opacity: opacity.value,
  }));

  if (!visible) return null;

  return (
    <View style={StyleSheet.absoluteFill} pointerEvents="none">
      <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
        <Animated.Text style={[{ fontSize: 64 }, animStyle]}>❤️</Animated.Text>
      </View>
    </View>
  );
}

// Simple line chart component (no external dependency needed as fallback)
function SimpleMoodChart({
  myData,
  partnerData,
  labels,
  theme,
}: {
  myData: number[];
  partnerData: number[];
  labels: string[];
  theme: any;
}) {
  const chartWidth = SCREEN_WIDTH - 80;
  const chartHeight = 150;
  const maxScore = 7;
  const stepX = chartWidth / Math.max(myData.length - 1, 1);

  const getY = (score: number) => chartHeight - (score / maxScore) * chartHeight;

  const renderLine = (data: number[], color: string) => {
    if (data.length < 2) return null;
    return data.map((val, i) => {
      if (i === 0 || val === 0) return null;
      const prevVal = data[i - 1];
      if (prevVal === 0) return null;
      return (
        <View
          key={`line-${color}-${i}`}
          style={{
            position: "absolute",
            left: (i - 1) * stepX,
            top: Math.min(getY(prevVal), getY(val)),
            width: stepX + 2,
            height: Math.abs(getY(val) - getY(prevVal)) + 3,
            borderBottomWidth: 2,
            borderBottomColor: color,
          }}
        />
      );
    });
  };

  const renderDots = (data: number[], color: string) => {
    return data.map((val, i) => {
      if (val === 0) return null;
      return (
        <View
          key={`dot-${color}-${i}`}
          style={{
            position: "absolute",
            left: i * stepX - 4,
            top: getY(val) - 4,
            width: 8,
            height: 8,
            borderRadius: 4,
            backgroundColor: color,
          }}
        />
      );
    });
  };

  return (
    <View style={{ marginTop: 12 }}>
      <View style={{ flexDirection: "row" }}>
        {/* Y-axis labels */}
        <View style={{ width: 30, height: chartHeight, justifyContent: "space-between" }}>
          {[7, 5, 3, 1].map(s => (
            <Text key={s} style={{ fontSize: scaledFont(9), color: theme.textLight, textAlign: "right" }}>
              {getMoodEmoji(s)}
            </Text>
          ))}
        </View>
        {/* Chart area */}
        <View style={{ width: chartWidth, height: chartHeight, marginLeft: 8, borderLeftWidth: 1, borderBottomWidth: 1, borderColor: theme.border }}>
          {renderDots(myData, theme.deepRose)}
          {renderDots(partnerData, theme.deepLavender)}
        </View>
      </View>
      {/* X-axis labels */}
      <View style={{ flexDirection: "row", marginLeft: 38, marginTop: 4 }}>
        {labels.map((l, i) => (
          i % 5 === 0 ? (
            <Text key={i} style={{ fontSize: scaledFont(9), color: theme.textLight, position: "absolute", left: i * stepX - 10 }}>
              {l}
            </Text>
          ) : null
        ))}
      </View>
      {/* Legend */}
      <View style={{ flexDirection: "row", justifyContent: "center", gap: 16, marginTop: 16 }}>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 4 }}>
          <View style={{ width: 12, height: 12, borderRadius: 6, backgroundColor: theme.deepRose }} />
          <Text style={{ fontSize: scaledFont(11), color: theme.textSecondary, fontFamily: "Nunito_400Regular" }}>You</Text>
        </View>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 4 }}>
          <View style={{ width: 12, height: 12, borderRadius: 6, backgroundColor: theme.deepLavender }} />
          <Text style={{ fontSize: scaledFont(11), color: theme.textSecondary, fontFamily: "Nunito_400Regular" }}>Partner</Text>
        </View>
      </View>
    </View>
  );
}

export default function MoodScreen() {
  const { user, userProfile, partnerProfile, coupleId } = useAuth();
  const { theme } = useTheme();
  const insets = useSafeAreaInsets();
  const [myMood, setMyMood] = useState("");
  const [partnerMood, setPartnerMood] = useState("");
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);
  const [showHistory, setShowHistory] = useState(false);
  const [heartVisible, setHeartVisible] = useState(false);

  // History data
  const [myHistory, setMyHistory] = useState<number[]>([]);
  const [partnerHistory, setPartnerHistory] = useState<number[]>([]);
  const [historyLabels, setHistoryLabels] = useState<string[]>([]);
  const [weeklyAvg, setWeeklyAvg] = useState(0);

  const today = new Date().toISOString().split("T")[0];

  useEffect(() => {
    if (!coupleId || !user) { setLoading(false); return; }
    const moodsRef = ref(db, `couples/${coupleId}/moods`);
    const handler = onValue(moodsRef, (snap) => {
      if (snap.exists()) {
        const myEntry = snap.child(`${user.uid}/${today}`).val();
        if (myEntry) {
          const moodVal = typeof myEntry === "object" ? myEntry.mood : myEntry;
          setMyMood(moodVal);
        }
        if (partnerProfile) {
          const partnerEntry = snap.child(`${partnerProfile.uid}/${today}`).val();
          if (partnerEntry) {
            const moodVal = typeof partnerEntry === "object" ? partnerEntry.mood : partnerEntry;
            setPartnerMood(moodVal);
          }
        }

        // Build history data (last 30 days)
        const now = new Date();
        const labels: string[] = [];
        const myScores: number[] = [];
        const partnerScores: number[] = [];

        for (let i = 29; i >= 0; i--) {
          const d = new Date(now);
          d.setDate(d.getDate() - i);
          const dateStr = d.toISOString().split("T")[0];
          labels.push(`${d.getMonth() + 1}/${d.getDate()}`);

          const myDayData = snap.child(`${user.uid}/${dateStr}`).val();
          if (myDayData) {
            const moodKey = typeof myDayData === "object" ? myDayData.mood : myDayData;
            const option = getMoodOption(moodKey);
            myScores.push(option?.score || 0);
          } else {
            myScores.push(0);
          }

          if (partnerProfile) {
            const partnerDayData = snap.child(`${partnerProfile.uid}/${dateStr}`).val();
            if (partnerDayData) {
              const moodKey = typeof partnerDayData === "object" ? partnerDayData.mood : partnerDayData;
              const option = getMoodOption(moodKey);
              partnerScores.push(option?.score || 0);
            } else {
              partnerScores.push(0);
            }
          } else {
            partnerScores.push(0);
          }
        }

        setHistoryLabels(labels);
        setMyHistory(myScores);
        setPartnerHistory(partnerScores);

        // Weekly average
        const lastWeek = myScores.slice(-7).filter(s => s > 0);
        if (lastWeek.length > 0) {
          setWeeklyAvg(Math.round(lastWeek.reduce((a, b) => a + b, 0) / lastWeek.length));
        }
      }
      setLoading(false);
    });
    return () => off(moodsRef, "value", handler);
  }, [coupleId, user, partnerProfile, today]);

  const saveMood = async (key: string) => {
    if (!coupleId || !user) return;
    setMyMood(key);
    setSaving(true);
    const option = getMoodOption(key);
    await set(ref(db, `couples/${coupleId}/moods/${user.uid}/${today}`), {
      mood: key,
      score: option?.score || 0,
    });
    setSaving(false);

    // Notify partner
    if (partnerProfile?.uid) {
      const tokenSnap = await get(ref(db, `users/${partnerProfile.uid}/pushToken`));
      if (tokenSnap.exists()) {
        sendPushNotification(
          tokenSnap.val(),
          `😊 ${userProfile?.name || "Partner"}`,
          `is feeling ${option?.label || key} today`,
          { screen: "/(tabs)/mood" }
        );
      }
    }
  };

  const sendQuickMessage = async (msg: string) => {
    if (!coupleId || !user || !userProfile) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    // Show heart
    setHeartVisible(true);
    setTimeout(() => setHeartVisible(false), 1200);

    // Send as chat message
    await push(ref(db, `couples/${coupleId}/messages`), {
      text: msg,
      senderId: user.uid,
      senderName: userProfile.name,
      timestamp: Date.now(),
      status: "sent",
    });

    // Notify partner
    if (partnerProfile?.uid) {
      const tokenSnap = await get(ref(db, `users/${partnerProfile.uid}/pushToken`));
      if (tokenSnap.exists()) {
        sendPushNotification(
          tokenSnap.val(),
          `💌 ${userProfile.name}`,
          msg,
          { screen: "/(tabs)" }
        );
      }
    }
  };

  const myMoodOption = getMoodOption(myMood);
  const partnerMoodOption = getMoodOption(partnerMood);
  const partnerName = partnerProfile?.name || "Partner";

  return (
    <View style={[styles.container, { backgroundColor: theme.offWhite }]}>
      <LinearGradient colors={[theme.headerGradientStart, theme.headerGradientEnd]} style={[styles.header, { paddingTop: insets.top + 12 }]}>
        <Text style={[styles.headerTitle, { color: theme.text }]}>Mood Check-in</Text>
        <Text style={[styles.headerSubtitle, { color: theme.textSecondary }]}>{new Date().toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" })}</Text>
      </LinearGradient>

      {loading ? (
        <View style={styles.centered}><ActivityIndicator color={theme.deepRose} /></View>
      ) : (
        <ScrollView contentContainerStyle={[styles.content, { paddingBottom: insets.bottom + 90 }]} showsVerticalScrollIndicator={false}>
          {/* Mood Summary */}
          {(myMood || partnerMood) && (
            <View style={[styles.moodSummary, { backgroundColor: theme.cardBg }]}>
              <View style={styles.moodCard}>
                <Text style={[styles.moodCardLabel, { color: theme.textSecondary }]}>You</Text>
                {myMoodOption ? (
                  <View style={[styles.moodDisplay, { backgroundColor: myMoodOption.bg }]}>
                    <Ionicons name={myMoodOption.icon} size={32} color={myMoodOption.color} />
                    <Text style={[styles.moodDisplayText, { color: myMoodOption.color }]}>{myMoodOption.label}</Text>
                  </View>
                ) : (
                  <View style={[styles.moodDisplay, { backgroundColor: theme.softPink }]}>
                    <Ionicons name="help-circle-outline" size={32} color={theme.textLight} />
                    <Text style={[styles.moodDisplayText, { color: theme.textLight }]}>Not set</Text>
                  </View>
                )}
              </View>
              <View style={styles.moodDivider}>
                <Ionicons name="heart" size={20} color={theme.deepRose} />
              </View>
              <View style={styles.moodCard}>
                <Text style={[styles.moodCardLabel, { color: theme.textSecondary }]}>{partnerName}</Text>
                {partnerMoodOption ? (
                  <View style={[styles.moodDisplay, { backgroundColor: partnerMoodOption.bg }]}>
                    <Ionicons name={partnerMoodOption.icon} size={32} color={partnerMoodOption.color} />
                    <Text style={[styles.moodDisplayText, { color: partnerMoodOption.color }]}>{partnerMoodOption.label}</Text>
                  </View>
                ) : (
                  <View style={[styles.moodDisplay, { backgroundColor: theme.softLavender }]}>
                    <Ionicons name="help-circle-outline" size={32} color={theme.textLight} />
                    <Text style={[styles.moodDisplayText, { color: theme.textLight }]}>Waiting...</Text>
                  </View>
                )}
              </View>
            </View>
          )}

          {/* Mood Selector */}
          <View style={styles.section}>
            <Text style={[styles.sectionTitle, { color: theme.text }]}>How are you feeling today?</Text>
            {saving && <ActivityIndicator size="small" color={theme.deepRose} style={{ marginBottom: 8 }} />}
            <MoodSelector selected={myMood} onSelect={saveMood} theme={theme} />
          </View>

          {/* Quick Messages */}
          <View style={styles.section}>
            <Text style={[styles.sectionTitle, { color: theme.text }]}>💌 Quick Messages</Text>
            <View style={styles.quickGrid}>
              {QUICK_MESSAGES.map((msg) => (
                <Pressable
                  key={msg}
                  onPress={() => sendQuickMessage(msg)}
                  style={({ pressed }) => [
                    styles.quickPill,
                    { backgroundColor: theme.accent + "20", opacity: pressed ? 0.7 : 1, minHeight: MIN_BUTTON_HEIGHT },
                  ]}
                >
                  <Text style={[styles.quickPillText, { color: theme.accent }]}>{msg}</Text>
                </Pressable>
              ))}
            </View>
          </View>

          {/* History Toggle */}
          <Pressable
            onPress={() => setShowHistory(!showHistory)}
            style={[styles.historyToggle, { backgroundColor: theme.cardBg, minHeight: MIN_BUTTON_HEIGHT }]}
          >
            <Ionicons name={showHistory ? "chevron-up" : "analytics-outline"} size={18} color={theme.deepRose} />
            <Text style={[styles.historyToggleText, { color: theme.deepRose }]}>
              {showHistory ? "Hide History" : "📊 View Mood History"}
            </Text>
          </Pressable>

          {/* Mood History */}
          {showHistory && (
            <View style={[styles.historyCard, { backgroundColor: theme.cardBg }]}>
              <Text style={[styles.sectionTitle, { color: theme.text }]}>Last 30 Days</Text>
              <SimpleMoodChart
                myData={myHistory}
                partnerData={partnerHistory}
                labels={historyLabels}
                theme={theme}
              />

              {weeklyAvg > 0 && (
                <View style={[styles.weeklyAvg, { backgroundColor: theme.softPink }]}>
                  <Text style={[styles.weeklyAvgText, { color: theme.text }]}>
                    This week you averaged: {getMoodEmoji(weeklyAvg)} {getMoodLabel(weeklyAvg)}
                  </Text>
                </View>
              )}
            </View>
          )}
        </ScrollView>
      )}

      <HeartConfirmation visible={heartVisible} />
    </View>
  );
}

const moodStyles = StyleSheet.create({
  grid: { flexDirection: "row", flexWrap: "wrap", gap: 12 },
  moodBtn: {
    width: "30%",
    aspectRatio: 1,
    borderRadius: 16,
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    position: "relative",
  },
  moodLabel: { fontFamily: "Nunito_600SemiBold", fontSize: scaledFont(12) },
  checkmark: { position: "absolute", top: 6, right: 6, width: 18, height: 18, borderRadius: 9, alignItems: "center", justifyContent: "center" },
});

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 24, paddingBottom: 20 },
  headerTitle: { fontFamily: "Nunito_800ExtraBold", fontSize: scaledFont(24) },
  headerSubtitle: { fontFamily: "Nunito_400Regular", fontSize: scaledFont(13), marginTop: 4 },
  centered: { flex: 1, alignItems: "center", justifyContent: "center" },
  content: { padding: 20, gap: 24 },
  moodSummary: {
    flexDirection: "row",
    borderRadius: 20,
    padding: 16,
    alignItems: "center",
    gap: 8,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 10,
    elevation: 2,
  },
  moodCard: { flex: 1, alignItems: "center", gap: 8 },
  moodCardLabel: { fontFamily: "Nunito_600SemiBold", fontSize: scaledFont(12) },
  moodDisplay: { borderRadius: 14, padding: 12, alignItems: "center", gap: 4, width: "100%" },
  moodDisplayText: { fontFamily: "Nunito_700Bold", fontSize: scaledFont(13) },
  moodDivider: { alignItems: "center", paddingHorizontal: 4 },
  section: { gap: 14 },
  sectionTitle: { fontFamily: "Nunito_700Bold", fontSize: scaledFont(16) },
  quickGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  quickPill: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 24,
    width: "48%",
    alignItems: "center",
  },
  quickPillText: { fontFamily: "Nunito_600SemiBold", fontSize: scaledFont(13), textAlign: "center" },
  historyToggle: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    borderRadius: 14,
    padding: 14,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 2,
  },
  historyToggleText: { fontFamily: "Nunito_700Bold", fontSize: scaledFont(14) },
  historyCard: {
    borderRadius: 20,
    padding: 16,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 10,
    elevation: 2,
  },
  weeklyAvg: {
    borderRadius: 14,
    padding: 14,
    marginTop: 12,
    alignItems: "center",
  },
  weeklyAvgText: { fontFamily: "Nunito_600SemiBold", fontSize: scaledFont(14) },
});
