import React, { useState, useEffect, useRef } from "react";
import {
  View, Text, StyleSheet, Pressable, ScrollView, ActivityIndicator,
  Platform, Alert, Switch,
} from "react-native";
import MapView, { Marker } from "react-native-maps";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import { ref, onValue } from "firebase/database";
import { useAuth } from "@/context/AuthContext";
import { useTheme } from "@/context/ThemeContext";
import { db } from "@/lib/firebase";
import { scaledFont, wp, MIN_BUTTON_HEIGHT } from "@/lib/responsive";
import { haversineDistance, formatDistance } from "@/lib/haversine";
import { startLocationUpdates, stopLocationUpdates, updateLocationOnce } from "@/lib/locationTask";

interface LocationData {
  lat: number;
  lng: number;
  timestamp: number;
  isSharing?: boolean;
  city?: string;
  weatherTemp?: number;
  weatherIcon?: string;
}

export default function LocationScreen() {
  const { user, coupleId, partnerProfile, userProfile } = useAuth();
  const { theme } = useTheme();
  const insets = useSafeAreaInsets();
  const mapRef = useRef<MapView>(null);
  const [myLocation, setMyLocation] = useState<LocationData | null>(null);
  const [partnerLocation, setPartnerLocation] = useState<LocationData | null>(null);
  const [isSharing, setIsSharing] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!coupleId || !user) { setLoading(false); return; }
    const myRef = ref(db, `couples/${coupleId}/location/${user.uid}`);
    const unsub1 = onValue(myRef, (snap) => {
      if (snap.exists()) {
        const data = snap.val();
        setMyLocation(data);
        setIsSharing(data.isSharing === true);
      }
      setLoading(false);
    });

    const members = ref(db, `couples/${coupleId}/members`);
    const unsub2 = onValue(members, (snap) => {
      if (!snap.exists()) return;
      const ids = Object.keys(snap.val());
      const partnerId = ids.find((id) => id !== user.uid);
      if (!partnerId) return;
      const partnerRef = ref(db, `couples/${coupleId}/location/${partnerId}`);
      onValue(partnerRef, (pSnap) => {
        if (pSnap.exists()) setPartnerLocation(pSnap.val());
      });
    });
    return () => { unsub1(); unsub2(); };
  }, [coupleId, user]);

  const toggleSharing = async () => {
    if (!user || !coupleId) return;
    if (isSharing) {
      await stopLocationUpdates(user.uid, coupleId);
      setIsSharing(false);
    } else {
      const success = await startLocationUpdates(user.uid, coupleId);
      if (success) {
        setIsSharing(true);
        await updateLocationOnce(user.uid, coupleId);
      } else {
        Alert.alert("Permission needed", "Please grant location permissions to share your location.");
      }
    }
  };

  const refreshLocation = async () => {
    if (!user || !coupleId) return;
    await updateLocationOnce(user.uid, coupleId);
  };

  const distance = myLocation && partnerLocation
    ? haversineDistance(myLocation.lat, myLocation.lng, partnerLocation.lat, partnerLocation.lng)
    : null;

  const getWeatherEmoji = (icon?: string) => {
    if (!icon) return "🌤";
    if (icon.includes("01")) return "☀️";
    if (icon.includes("02") || icon.includes("03")) return "⛅";
    if (icon.includes("04")) return "☁️";
    if (icon.includes("09") || icon.includes("10")) return "🌧";
    if (icon.includes("11")) return "⛈";
    if (icon.includes("13")) return "❄️";
    if (icon.includes("50")) return "🌫";
    return "🌤";
  };

  // Only show map if partner is sharing location
  const showMap = partnerLocation && partnerLocation.isSharing;

  const mapRegion = partnerLocation
    ? { latitude: partnerLocation.lat, longitude: partnerLocation.lng, latitudeDelta: 0.05, longitudeDelta: 0.05 }
    : { latitude: 20.5937, longitude: 78.9629, latitudeDelta: 20, longitudeDelta: 20 };

  if (loading) {
    return (
      <View style={[styles.container, { backgroundColor: theme.background }]}>
        <ActivityIndicator color={theme.deepRose} size="large" style={{ flex: 1 }} />
      </View>
    );
  }

  return (
    <View style={[styles.container, { backgroundColor: theme.background }]}>
      <LinearGradient colors={[theme.headerGradientStart, theme.headerGradientEnd]} style={[styles.header, { paddingTop: insets.top + 12 }]}>
        <Text style={[styles.headerTitle, { color: theme.text }]}>📍 Our Location</Text>
        {distance !== null && (
          <Text style={[styles.distanceText, { color: theme.deepRose }]}>
            {formatDistance(distance)} apart
          </Text>
        )}
      </LinearGradient>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingBottom: insets.bottom + 90, paddingHorizontal: 16, paddingTop: 12, gap: 12 }}
        showsVerticalScrollIndicator={false}
      >
        {/* Sharing toggle */}
        <View style={[styles.sharingCard, { backgroundColor: theme.cardBg, borderColor: theme.border }]}>
          <View style={{ flex: 1 }}>
            <Text style={[styles.sharingTitle, { color: theme.text }]}>Live Location Sharing</Text>
            <Text style={[styles.sharingStatus, { color: theme.textSecondary }]}>
              {isSharing ? "🟢 Sharing with your partner" : "⚪ Location sharing paused"}
            </Text>
          </View>
          <Switch
            value={isSharing}
            onValueChange={toggleSharing}
            trackColor={{ false: theme.border, true: theme.deepRose + "80" }}
            thumbColor={isSharing ? theme.deepRose : theme.textLight}
          />
        </View>

        {/* Map - only shown when partner is sharing */}
        {showMap ? (
          <View style={[styles.mapCard, { borderColor: theme.border }]}>
            <MapView
              ref={mapRef}
              style={styles.map}
              initialRegion={mapRegion}
            >
              {partnerLocation && (
                <Marker
                  coordinate={{ latitude: partnerLocation.lat, longitude: partnerLocation.lng }}
                  title={partnerProfile?.name || "Partner"}
                  description={partnerLocation.city || "Partner's location"}
                  pinColor="#C49AE8"
                />
              )}
              {myLocation && myLocation.isSharing && (
                <Marker
                  coordinate={{ latitude: myLocation.lat, longitude: myLocation.lng }}
                  title="You"
                  description={myLocation.city || "Your location"}
                  pinColor="#FF6B9D"
                />
              )}
            </MapView>

            {/* Refresh button on map */}
            <Pressable onPress={refreshLocation} style={[styles.mapBtn, { backgroundColor: theme.cardBg }]}>
              <Ionicons name="refresh" size={20} color={theme.text} />
            </Pressable>
          </View>
        ) : (
          <View style={[styles.noMapCard, { backgroundColor: theme.cardBg, borderColor: theme.border }]}>
            <Ionicons name="map-outline" size={40} color={theme.textLight} />
            <Text style={[styles.noMapText, { color: theme.textSecondary }]}>
              {!partnerProfile ? "Connect with your partner first" : "Your partner hasn't shared their location yet"}
            </Text>
            <Text style={[styles.noMapHint, { color: theme.textLight }]}>
              The map will appear once your partner shares their location
            </Text>
          </View>
        )}

        {/* Weather cards */}
        <View style={styles.weatherRow}>
          <View style={[styles.weatherCard, { backgroundColor: theme.cardBg, borderColor: theme.border }]}>
            <Text style={styles.weatherEmoji}>{getWeatherEmoji(myLocation?.weatherIcon)}</Text>
            <Text style={[styles.weatherName, { color: theme.text }]}>You</Text>
            <Text style={[styles.weatherCity, { color: theme.textSecondary }]}>{myLocation?.city || "—"}</Text>
            {myLocation?.weatherTemp !== undefined && (
              <Text style={[styles.weatherTemp, { color: theme.deepRose }]}>{myLocation.weatherTemp}°C</Text>
            )}
          </View>
          <View style={[styles.weatherCard, { backgroundColor: theme.cardBg, borderColor: theme.border }]}>
            <Text style={styles.weatherEmoji}>{getWeatherEmoji(partnerLocation?.weatherIcon)}</Text>
            <Text style={[styles.weatherName, { color: theme.text }]}>{partnerProfile?.name || "Partner"}</Text>
            <Text style={[styles.weatherCity, { color: theme.textSecondary }]}>{partnerLocation?.city || "—"}</Text>
            {partnerLocation?.weatherTemp !== undefined && (
              <Text style={[styles.weatherTemp, { color: theme.deepLavender }]}>{partnerLocation.weatherTemp}°C</Text>
            )}
          </View>
        </View>

        {/* Distance card */}
        {distance !== null && (
          <View style={[styles.distanceCard, { backgroundColor: theme.cardBg, borderColor: theme.border }]}>
            <Ionicons name="navigate-outline" size={22} color={theme.deepRose} />
            <View style={{ flex: 1 }}>
              <Text style={[styles.distanceLabel, { color: theme.textSecondary }]}>Distance between you</Text>
              <Text style={[styles.distanceBig, { color: theme.deepRose }]}>{formatDistance(distance)}</Text>
            </View>
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 20, paddingBottom: 14, alignItems: "center" },
  headerTitle: { fontFamily: "Nunito_700Bold", fontSize: scaledFont(20) },
  distanceText: { fontFamily: "Nunito_800ExtraBold", fontSize: scaledFont(16), marginTop: 4 },
  sharingCard: {
    flexDirection: "row", alignItems: "center", padding: 16, borderRadius: 16,
    borderWidth: 1,
  },
  sharingTitle: { fontFamily: "Nunito_700Bold", fontSize: scaledFont(15) },
  sharingStatus: { fontFamily: "Nunito_400Regular", fontSize: scaledFont(12), marginTop: 2 },
  mapCard: {
    borderRadius: 16, overflow: "hidden", height: 240, borderWidth: 1,
    position: "relative",
  },
  map: { flex: 1 },
  mapBtn: {
    position: "absolute", top: 10, right: 10,
    width: 40, height: 40, borderRadius: 20, alignItems: "center", justifyContent: "center",
    shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.15, shadowRadius: 6, elevation: 4,
  },
  noMapCard: {
    borderRadius: 16, padding: 32, alignItems: "center", borderWidth: 1, gap: 8,
  },
  noMapText: { fontFamily: "Nunito_600SemiBold", fontSize: scaledFont(14), textAlign: "center" },
  noMapHint: { fontFamily: "Nunito_400Regular", fontSize: scaledFont(12), textAlign: "center" },
  weatherRow: { flexDirection: "row", gap: 12 },
  weatherCard: {
    flex: 1, alignItems: "center", padding: 16, borderRadius: 16, borderWidth: 1, gap: 4,
  },
  weatherEmoji: { fontSize: 28 },
  weatherName: { fontFamily: "Nunito_700Bold", fontSize: scaledFont(14) },
  weatherCity: { fontFamily: "Nunito_400Regular", fontSize: scaledFont(12) },
  weatherTemp: { fontFamily: "Nunito_800ExtraBold", fontSize: scaledFont(20) },
  distanceCard: {
    flexDirection: "row", alignItems: "center", padding: 16, borderRadius: 16,
    borderWidth: 1, gap: 14,
  },
  distanceLabel: { fontFamily: "Nunito_400Regular", fontSize: scaledFont(12) },
  distanceBig: { fontFamily: "Nunito_800ExtraBold", fontSize: scaledFont(20) },
});
