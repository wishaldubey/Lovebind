import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  TextInput,
  Modal,
  ScrollView,
  Alert,
  ActivityIndicator,
  Switch,
  Platform,
  KeyboardAvoidingView,
  Dimensions,
} from "react-native";
import { SafeAreaView, useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { ref, onValue, set } from "firebase/database";
import { db } from "@/lib/firebase";
import { useAuth } from "@/context/AuthContext";
import { useTheme } from "@/context/ThemeContext";
import { scaledFont, MIN_BUTTON_HEIGHT, wp } from "@/lib/responsive";
import { haversineDistance, formatDistance } from "@/lib/haversine";
import { router } from "expo-router";

const { width: SCREEN_WIDTH } = Dimensions.get("window");

function AvatarCircle({ name, color, size = 56 }: { name: string; color: string; size?: number }) {
  return (
    <View style={[profileStyles.avatar, { width: size, height: size, borderRadius: size / 2, backgroundColor: color }]}>
      <Text style={[profileStyles.avatarText, { fontSize: size * 0.38 }]}>{name.charAt(0).toUpperCase()}</Text>
    </View>
  );
}

function InfoRow({ icon, label, value, theme }: { icon: keyof typeof Ionicons.glyphMap; label: string; value: string; theme: any }) {
  return (
    <View style={profileStyles.infoRow}>
      <View style={[profileStyles.infoIcon, { backgroundColor: theme.softPink }]}>
        <Ionicons name={icon} size={16} color={theme.deepRose} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={[profileStyles.infoLabel, { color: theme.textSecondary }]}>{label}</Text>
        <Text style={[profileStyles.infoValue, { color: theme.text }]}>{value || "Not set"}</Text>
      </View>
    </View>
  );
}

function useDaysTogether(anniversaryDate?: string | null) {
  const [days, setDays] = useState(0);
  useEffect(() => {
    if (!anniversaryDate) { setDays(0); return; }
    const update = () => {
      const ann = new Date(anniversaryDate);
      const now = new Date();
      const diff = Math.floor((now.getTime() - ann.getTime()) / (1000 * 60 * 60 * 24));
      setDays(Math.max(0, diff));
    };
    update();
    const interval = setInterval(update, 60000);
    return () => clearInterval(interval);
  }, [anniversaryDate]);
  return days;
}

function useYearsTogether(anniversaryDate?: string | null) {
  if (!anniversaryDate) return 0;
  const ann = new Date(anniversaryDate);
  const now = new Date();
  return now.getFullYear() - ann.getFullYear();
}

export default function ProfileScreen() {
  const { user, userProfile, partnerProfile, signOut, updateUserProfile, coupleId } = useAuth();
  const { theme, isDark, toggleTheme, isAnniversary } = useTheme();
  const insets = useSafeAreaInsets();
  const [editVisible, setEditVisible] = useState(false);
  const [editName, setEditName] = useState(userProfile?.name || "");
  const [editAnniversary, setEditAnniversary] = useState("");
  const [saving, setSaving] = useState(false);

  // Anniversary from shared couple path
  const [anniversary, setAnniversary] = useState<string | null>(null);
  const [distance, setDistance] = useState<number | null>(null);

  // Listen to couple anniversary
  useEffect(() => {
    if (!coupleId) return;
    const annRef = ref(db, `couples/${coupleId}/anniversary`);
    const unsub = onValue(annRef, (snap) => {
      if (snap.exists()) {
        setAnniversary(snap.val());
      }
    });
    return () => unsub();
  }, [coupleId]);

  // Listen to distance
  useEffect(() => {
    if (!coupleId || !user || !partnerProfile) return;
    const myLocRef = ref(db, `couples/${coupleId}/location/${user.uid}`);
    const partnerLocRef = ref(db, `couples/${coupleId}/location/${partnerProfile.uid}`);

    let myLoc: any = null;
    let partnerLoc: any = null;

    const unsub1 = onValue(myLocRef, (snap) => {
      if (snap.exists()) {
        myLoc = snap.val();
        if (myLoc && partnerLoc && myLoc.isSharing && partnerLoc.isSharing) {
          setDistance(haversineDistance(myLoc.lat, myLoc.lng, partnerLoc.lat, partnerLoc.lng));
        }
      }
    });

    const unsub2 = onValue(partnerLocRef, (snap) => {
      if (snap.exists()) {
        partnerLoc = snap.val();
        if (myLoc && partnerLoc && myLoc.isSharing && partnerLoc.isSharing) {
          setDistance(haversineDistance(myLoc.lat, myLoc.lng, partnerLoc.lat, partnerLoc.lng));
        }
      }
    });

    return () => { unsub1(); unsub2(); };
  }, [coupleId, user, partnerProfile]);

  const daysTogether = useDaysTogether(anniversary);
  const yearsTogether = useYearsTogether(anniversary);

  const openEdit = () => {
    setEditName(userProfile?.name || "");
    setEditAnniversary(anniversary || "");
    setEditVisible(true);
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await updateUserProfile({ name: editName.trim() });
      // Save anniversary to shared couple path
      if (coupleId && editAnniversary.trim()) {
        await set(ref(db, `couples/${coupleId}/anniversary`), editAnniversary.trim());
      }
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setEditVisible(false);
    } catch {
      Alert.alert("Error", "Could not save profile.");
    } finally {
      setSaving(false);
    }
  };

  const handleSignOut = () => {
    Alert.alert("Sign out?", "You'll need to sign in again.", [
      { text: "Cancel", style: "cancel" },
      { text: "Sign out", style: "destructive", onPress: async () => {
        await signOut();
        router.replace("/");
      }},
    ]);
  };

  return (
    <View style={[styles.container, { backgroundColor: theme.offWhite }]}>
      <LinearGradient colors={[theme.headerGradientStart, theme.headerGradientEnd]} style={[styles.header, { paddingTop: insets.top + 16 }]}>
        <View style={styles.headerRow}>
          <Text style={[styles.headerTitle, { color: theme.text }]}>Profile</Text>
          <View style={styles.headerActions}>
            <Pressable onPress={openEdit} style={[styles.iconBtn, { backgroundColor: (theme.white || "#fff") + "80", minHeight: MIN_BUTTON_HEIGHT }]}>
              <Ionicons name="pencil-outline" size={20} color={theme.text} />
            </Pressable>
          </View>
        </View>

        {/* Anniversary Banner */}
        {isAnniversary && anniversary && (
          <View style={styles.anniversaryBanner}>
            <Text style={styles.anniversaryBannerText}>
              🎉 Happy Anniversary {yearsTogether} Years! 💍
            </Text>
          </View>
        )}

        {/* Days Together Counter */}
        {anniversary ? (
          <View style={styles.countdown}>
            <LinearGradient colors={[theme.cardBg, theme.softPink]} style={styles.countdownCard}>
              <Ionicons name="heart" size={20} color={theme.deepRose} />
              <Text style={[styles.countdownNumber, { color: theme.deepRose }]}>{daysTogether.toLocaleString()}</Text>
              <Text style={[styles.countdownLabel, { color: theme.textSecondary }]}>days together</Text>
            </LinearGradient>
          </View>
        ) : null}

        {/* Distance subtitle */}
        {distance !== null && (
          <Text style={[styles.distanceSubtitle, { color: theme.textSecondary }]}>
            📍 {formatDistance(distance)}
          </Text>
        )}
      </LinearGradient>

      <ScrollView contentContainerStyle={[styles.content, { paddingBottom: insets.bottom + 90 }]} showsVerticalScrollIndicator={false}>
        {/* Couple Card */}
        <View style={[styles.coupleCard, { backgroundColor: theme.cardBg, borderColor: isAnniversary ? "#FFD700" : "transparent", borderWidth: isAnniversary ? 2 : 0 }]}>
          <View style={styles.coupleAvatars}>
            <View style={styles.avatarBlock}>
              <AvatarCircle name={userProfile?.name || "?"} color={theme.deepRose} size={64} />
              <Text style={[styles.avatarName, { color: theme.text }]}>{userProfile?.name || "You"}</Text>
              <Text style={[styles.avatarSub, { color: theme.textSecondary }]}>You</Text>
            </View>
            <View style={styles.heartDivider}>
              <Ionicons name="heart" size={24} color={theme.deepRose} />
            </View>
            <View style={styles.avatarBlock}>
              <AvatarCircle name={partnerProfile?.name || "?"} color={theme.deepLavender} size={64} />
              <Text style={[styles.avatarName, { color: theme.text }]}>{partnerProfile?.name || "Partner"}</Text>
              <Text style={[styles.avatarSub, { color: theme.textSecondary }]}>{partnerProfile ? "Connected" : "Waiting..."}</Text>
            </View>
          </View>
        </View>

        {/* Dark Mode Toggle */}
        <View style={[styles.settingCard, { backgroundColor: theme.cardBg }]}>
          <View style={{ flexDirection: "row", alignItems: "center", gap: 12, flex: 1 }}>
            <Ionicons name={isDark ? "moon" : "sunny"} size={20} color={theme.deepRose} />
            <Text style={[styles.settingLabel, { color: theme.text }]}>Dark Mode</Text>
          </View>
          <Switch
            value={isDark}
            onValueChange={toggleTheme}
            trackColor={{ false: theme.border, true: theme.deepRose + "60" }}
            thumbColor={isDark ? theme.deepRose : theme.textLight}
          />
        </View>

        {/* Your Info */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: theme.textSecondary }]}>Your info</Text>
          <View style={[styles.infoCard, { backgroundColor: theme.cardBg }]}>
            <InfoRow icon="person-outline" label="Name" value={userProfile?.name || ""} theme={theme} />
            <View style={[styles.divider, { backgroundColor: theme.border }]} />
            <InfoRow icon="mail-outline" label="Email" value={userProfile?.email || ""} theme={theme} />
            {anniversary && (
              <>
                <View style={[styles.divider, { backgroundColor: theme.border }]} />
                <InfoRow icon="calendar-outline" label="Anniversary" value={anniversary} theme={theme} />
              </>
            )}
          </View>
        </View>

        {/* Partner Info */}
        {partnerProfile && (
          <View style={styles.section}>
            <Text style={[styles.sectionTitle, { color: theme.textSecondary }]}>Partner info</Text>
            <View style={[styles.infoCard, { backgroundColor: theme.cardBg }]}>
              <InfoRow icon="person-outline" label="Name" value={partnerProfile.name} theme={theme} />
              <View style={[styles.divider, { backgroundColor: theme.border }]} />
              <InfoRow icon="mail-outline" label="Email" value={partnerProfile.email} theme={theme} />
            </View>
          </View>
        )}

        {/* Couple ID */}
        {coupleId && (
          <View style={styles.section}>
            <Text style={[styles.sectionTitle, { color: theme.textSecondary }]}>Couple ID</Text>
            <View style={[styles.infoCard, { backgroundColor: theme.cardBg }]}>
              <Text style={[styles.coupleIdText, { color: theme.textSecondary }]} numberOfLines={1}>{coupleId}</Text>
            </View>
          </View>
        )}

        {/* Sign Out */}
        <Pressable onPress={handleSignOut} style={({ pressed }) => [styles.signOutBtn, { backgroundColor: theme.softPink, opacity: pressed ? 0.8 : 1, minHeight: MIN_BUTTON_HEIGHT }]}>
          <Ionicons name="log-out-outline" size={18} color={theme.deepRose} />
          <Text style={[styles.signOutText, { color: theme.deepRose }]}>Sign Out</Text>
        </Pressable>
      </ScrollView>

      {/* Edit Modal */}
      <Modal visible={editVisible} animationType="slide" presentationStyle="pageSheet">
        <SafeAreaView style={[{ flex: 1, backgroundColor: theme.cardBg }]}>
          <KeyboardAvoidingView
            behavior={Platform.OS === "ios" ? "padding" : "height"}
            style={{ flex: 1 }}
          >
            <View style={[styles.modalHeader, { borderBottomColor: theme.border }]}>
              <Pressable onPress={() => setEditVisible(false)} style={{ minHeight: MIN_BUTTON_HEIGHT, justifyContent: "center" }}>
                <Ionicons name="close" size={24} color={theme.text} />
              </Pressable>
              <Text style={[styles.modalTitle, { color: theme.text }]}>Edit Profile</Text>
              <Pressable onPress={handleSave} disabled={saving} style={{ minHeight: MIN_BUTTON_HEIGHT, justifyContent: "center" }}>
                {saving ? <ActivityIndicator size="small" color={theme.deepRose} /> : (
                  <Text style={[styles.saveText, { color: theme.deepRose }]}>Save</Text>
                )}
              </Pressable>
            </View>

            <ScrollView contentContainerStyle={styles.modalContent} keyboardShouldPersistTaps="handled">
              <View style={styles.field}>
                <Text style={[styles.fieldLabel, { color: theme.textSecondary }]}>Your name</Text>
                <TextInput
                  style={[styles.fieldInput, { backgroundColor: theme.inputBg, color: theme.text }]}
                  value={editName}
                  onChangeText={setEditName}
                  placeholder="Name"
                  placeholderTextColor={theme.textLight}
                  autoCapitalize="words"
                />
              </View>
              <View style={styles.field}>
                <Text style={[styles.fieldLabel, { color: theme.textSecondary }]}>Anniversary date</Text>
                <TextInput
                  style={[styles.fieldInput, { backgroundColor: theme.inputBg, color: theme.text }]}
                  value={editAnniversary}
                  onChangeText={setEditAnniversary}
                  placeholder="YYYY-MM-DD"
                  placeholderTextColor={theme.textLight}
                />
                <Text style={[styles.fieldHint, { color: theme.textLight }]}>Shared with your partner — both of you will see this date</Text>
              </View>
            </ScrollView>
          </KeyboardAvoidingView>
        </SafeAreaView>
      </Modal>
    </View>
  );
}

const profileStyles = StyleSheet.create({
  avatar: { alignItems: "center", justifyContent: "center", borderWidth: 3, borderColor: "#fff" },
  avatarText: { fontFamily: "Nunito_800ExtraBold", color: "#fff" },
  infoRow: { flexDirection: "row", alignItems: "center", gap: 12, paddingVertical: 12 },
  infoIcon: { width: 32, height: 32, borderRadius: 16, alignItems: "center", justifyContent: "center" },
  infoLabel: { fontFamily: "Nunito_400Regular", fontSize: scaledFont(11) },
  infoValue: { fontFamily: "Nunito_600SemiBold", fontSize: scaledFont(14), marginTop: 1 },
});

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 24, paddingBottom: 20 },
  headerRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  headerTitle: { fontFamily: "Nunito_800ExtraBold", fontSize: scaledFont(24) },
  headerActions: { flexDirection: "row", gap: 8 },
  iconBtn: { width: 38, height: 38, borderRadius: 19, alignItems: "center", justifyContent: "center" },
  anniversaryBanner: {
    backgroundColor: "#FFF3E0",
    borderRadius: 14,
    padding: 14,
    marginTop: 12,
    alignItems: "center",
    borderWidth: 1.5,
    borderColor: "#E8B44F",
  },
  anniversaryBannerText: { fontFamily: "Nunito_800ExtraBold", fontSize: scaledFont(15), color: "#8B6914", textAlign: "center" },
  countdown: { marginTop: 14 },
  countdownCard: { borderRadius: 18, padding: 16, alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 12 },
  countdownNumber: { fontFamily: "Nunito_800ExtraBold", fontSize: scaledFont(26) },
  countdownLabel: { fontFamily: "Nunito_400Regular", fontSize: scaledFont(14) },
  distanceSubtitle: { fontFamily: "Nunito_600SemiBold", fontSize: scaledFont(13), marginTop: 8, textAlign: "center" },
  content: { padding: 20, gap: 20 },
  coupleCard: { borderRadius: 20, padding: 24, shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.06, shadowRadius: 10, elevation: 3 },
  coupleAvatars: { flexDirection: "row", justifyContent: "center", alignItems: "center", gap: 16 },
  avatarBlock: { alignItems: "center", gap: 6 },
  heartDivider: { alignItems: "center", paddingHorizontal: 8 },
  avatarName: { fontFamily: "Nunito_700Bold", fontSize: scaledFont(14), textAlign: "center" },
  avatarSub: { fontFamily: "Nunito_400Regular", fontSize: scaledFont(11) },
  settingCard: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 16,
    padding: 16,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  settingLabel: { fontFamily: "Nunito_600SemiBold", fontSize: scaledFont(15) },
  section: { gap: 10 },
  sectionTitle: { fontFamily: "Nunito_700Bold", fontSize: scaledFont(14), paddingLeft: 4 },
  infoCard: { borderRadius: 16, paddingHorizontal: 16, shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.05, shadowRadius: 8, elevation: 2 },
  divider: { height: 1 },
  coupleIdText: { fontFamily: "Nunito_400Regular", fontSize: scaledFont(12), padding: 16 },
  signOutBtn: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, borderRadius: 14, padding: 16 },
  signOutText: { fontFamily: "Nunito_700Bold", fontSize: scaledFont(15) },
  modalHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", padding: 20, borderBottomWidth: 1 },
  modalTitle: { fontFamily: "Nunito_700Bold", fontSize: scaledFont(17) },
  saveText: { fontFamily: "Nunito_700Bold", fontSize: scaledFont(16) },
  modalContent: { padding: 24, gap: 20 },
  field: { gap: 6 },
  fieldLabel: { fontFamily: "Nunito_600SemiBold", fontSize: scaledFont(13) },
  fieldInput: { borderRadius: 12, padding: 14, fontFamily: "Nunito_400Regular", fontSize: scaledFont(15) },
  fieldHint: { fontFamily: "Nunito_400Regular", fontSize: scaledFont(11) },
});
