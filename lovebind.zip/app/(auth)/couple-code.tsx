import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  Pressable,
  ActivityIndicator,
  Alert,
  Share,
} from "react-native";
import { router } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import * as Clipboard from "expo-clipboard";
import { useAuth } from "@/context/AuthContext";
import Colors from "@/constants/colors";
import { scaledFont, MIN_BUTTON_HEIGHT } from "@/lib/responsive";

export default function CoupleCodeScreen() {
  const { createCoupleCode, joinCouple, signOut } = useAuth();
  const insets = useSafeAreaInsets();
  const [mode, setMode] = useState<"choose" | "create" | "join">("choose");
  const [generatedCode, setGeneratedCode] = useState("");
  const [inputCode, setInputCode] = useState("");
  const [loading, setLoading] = useState(false);

  const handleCreate = async () => {
    setLoading(true);
    try {
      const code = await createCoupleCode();
      setGeneratedCode(code);
      setMode("create");
    } catch (e: any) {
      Alert.alert("Error", e.message);
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = async () => {
    await Clipboard.setStringAsync(generatedCode);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    Alert.alert("Copied!", "Share this code with your partner.");
  };

  const handleShare = async () => {
    await Share.share({ message: `Join me on our couple app! Use code: ${generatedCode}` });
  };

  const handleJoin = async () => {
    if (!inputCode.trim()) {
      Alert.alert("Enter code", "Please enter your partner's code.");
      return;
    }
    setLoading(true);
    try {
      await joinCouple(inputCode.trim());
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      router.replace("/");
    } catch (e: any) {
      Alert.alert("Invalid Code", e.message || "Could not find that code.");
    } finally {
      setLoading(false);
    }
  };

  const handleContinue = () => {
    router.replace("/");
  };

  return (
    <LinearGradient colors={[Colors.softPink, Colors.softLavender]} style={styles.gradient}>
      <View style={[styles.container, { paddingTop: insets.top + 40, paddingBottom: insets.bottom + 24 }]}>
        <View style={styles.header}>
          <View style={styles.iconWrap}>
            <Ionicons name="link" size={36} color={Colors.deepRose} />
          </View>
          <Text style={styles.title}>Connect with your partner</Text>
          <Text style={styles.subtitle}>Link your accounts to share your journey</Text>
        </View>

        {mode === "choose" && (
          <View style={styles.choices}>
            <Pressable
              style={({ pressed }) => [styles.choiceCard, { opacity: pressed ? 0.85 : 1 }]}
              onPress={handleCreate}
              disabled={loading}
            >
              <LinearGradient colors={[Colors.white, Colors.softPink]} style={styles.choiceGrad}>
                {loading ? (
                  <ActivityIndicator color={Colors.deepRose} />
                ) : (
                  <>
                    <Ionicons name="add-circle" size={36} color={Colors.deepRose} />
                    <Text style={styles.choiceTitle}>Create a code</Text>
                    <Text style={styles.choiceDesc}>Generate a code and share it with your partner</Text>
                  </>
                )}
              </LinearGradient>
            </Pressable>

            <Pressable
              style={({ pressed }) => [styles.choiceCard, { opacity: pressed ? 0.85 : 1 }]}
              onPress={() => setMode("join")}
            >
              <LinearGradient colors={[Colors.white, Colors.softLavender]} style={styles.choiceGrad}>
                <Ionicons name="enter" size={36} color={Colors.deepLavender} />
                <Text style={styles.choiceTitle}>Enter a code</Text>
                <Text style={styles.choiceDesc}>Use a code your partner already created</Text>
              </LinearGradient>
            </Pressable>

            <Pressable onPress={() => signOut()} style={[styles.signOutBtn, { minHeight: MIN_BUTTON_HEIGHT }]}>
              <Text style={styles.signOutText}>Sign out</Text>
            </Pressable>
          </View>
        )}

        {mode === "create" && (
          <View style={styles.codeDisplay}>
            <Text style={styles.codeLabel}>Your couple code</Text>
            <View style={styles.codeBadge}>
              <Text style={styles.codeText}>{generatedCode}</Text>
            </View>
            <Text style={styles.codeHint}>Share this with your partner. Once they join, you'll be connected!</Text>

            <View style={styles.codeActions}>
              <Pressable onPress={handleCopy} style={({ pressed }) => [styles.actionBtn, styles.actionBtnOutline, { opacity: pressed ? 0.8 : 1 }]}>
                <Ionicons name="copy-outline" size={18} color={Colors.deepRose} />
                <Text style={[styles.actionBtnText, { color: Colors.deepRose }]}>Copy</Text>
              </Pressable>
              <Pressable onPress={handleShare} style={({ pressed }) => [styles.actionBtn, styles.actionBtnOutline, { opacity: pressed ? 0.8 : 1 }]}>
                <Ionicons name="share-outline" size={18} color={Colors.deepRose} />
                <Text style={[styles.actionBtnText, { color: Colors.deepRose }]}>Share</Text>
              </Pressable>
            </View>

            <Pressable onPress={handleContinue} style={({ pressed }) => [styles.continueBtn, { opacity: pressed ? 0.85 : 1 }]}>
              <LinearGradient colors={[Colors.blush, Colors.deepRose]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={styles.btnGradient}>
                <Text style={styles.btnText}>Continue without partner</Text>
              </LinearGradient>
            </Pressable>
          </View>
        )}

        {mode === "join" && (
          <View style={styles.joinForm}>
            <Pressable onPress={() => setMode("choose")} style={styles.backBtn}>
              <Ionicons name="chevron-back" size={20} color={Colors.text} />
              <Text style={styles.backBtnText}>Back</Text>
            </Pressable>

            <Text style={styles.joinLabel}>Enter your partner's code</Text>
            <View style={styles.inputWrapper}>
              <TextInput
                style={styles.codeInput}
                placeholder="ABC123"
                placeholderTextColor={Colors.textLight}
                value={inputCode}
                onChangeText={setInputCode}
                autoCapitalize="characters"
                maxLength={8}
              />
            </View>

            <Pressable
              style={({ pressed }) => [styles.continueBtn, { opacity: pressed ? 0.85 : 1 }]}
              onPress={handleJoin}
              disabled={loading}
            >
              <LinearGradient colors={[Colors.lavender, Colors.deepLavender]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={styles.btnGradient}>
                {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.btnText}>Connect</Text>}
              </LinearGradient>
            </Pressable>
          </View>
        )}
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  gradient: { flex: 1 },
  container: { flex: 1, paddingHorizontal: 24 },
  header: { alignItems: "center", marginBottom: 32 },
  iconWrap: {
    width: 72, height: 72, borderRadius: 36,
    backgroundColor: Colors.white, alignItems: "center", justifyContent: "center",
    marginBottom: 16,
    shadowColor: Colors.deepRose, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.15, shadowRadius: 12, elevation: 6,
  },
  title: { fontFamily: "Nunito_800ExtraBold", fontSize: scaledFont(24), color: Colors.text, marginBottom: 6, textAlign: "center" },
  subtitle: { fontFamily: "Nunito_400Regular", fontSize: scaledFont(14), color: Colors.textSecondary, textAlign: "center" },
  choices: { gap: 14 },
  choiceCard: { borderRadius: 20, overflow: "hidden", shadowColor: "#000", shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.08, shadowRadius: 10, elevation: 3 },
  choiceGrad: { padding: 24, alignItems: "center", gap: 8 },
  choiceTitle: { fontFamily: "Nunito_700Bold", fontSize: 17, color: Colors.text },
  choiceDesc: { fontFamily: "Nunito_400Regular", fontSize: 13, color: Colors.textSecondary, textAlign: "center" },
  signOutBtn: { alignItems: "center", paddingVertical: 12, marginTop: 4 },
  signOutText: { fontFamily: "Nunito_600SemiBold", fontSize: 14, color: Colors.textSecondary },
  codeDisplay: { alignItems: "center", gap: 16 },
  codeLabel: { fontFamily: "Nunito_600SemiBold", fontSize: 14, color: Colors.textSecondary },
  codeBadge: {
    backgroundColor: Colors.white, borderRadius: 16, paddingHorizontal: 32, paddingVertical: 20,
    shadowColor: Colors.deepRose, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.15, shadowRadius: 12, elevation: 4,
  },
  codeText: { fontFamily: "Nunito_800ExtraBold", fontSize: 36, color: Colors.deepRose, letterSpacing: 6 },
  codeHint: { fontFamily: "Nunito_400Regular", fontSize: 13, color: Colors.textSecondary, textAlign: "center", paddingHorizontal: 20 },
  codeActions: { flexDirection: "row", gap: 12 },
  actionBtn: { flexDirection: "row", alignItems: "center", gap: 6, paddingVertical: 10, paddingHorizontal: 20, borderRadius: 12 },
  actionBtnOutline: { borderWidth: 1.5, borderColor: Colors.deepRose },
  actionBtnText: { fontFamily: "Nunito_600SemiBold", fontSize: 14 },
  continueBtn: { width: "100%", marginTop: 8 },
  btnGradient: { paddingVertical: 16, borderRadius: 14, alignItems: "center", minHeight: MIN_BUTTON_HEIGHT },
  btnText: { fontFamily: "Nunito_700Bold", fontSize: scaledFont(16), color: "#fff" },
  joinForm: { gap: 16 },
  backBtn: { flexDirection: "row", alignItems: "center", gap: 4, marginBottom: 8 },
  backBtnText: { fontFamily: "Nunito_600SemiBold", fontSize: 14, color: Colors.text },
  joinLabel: { fontFamily: "Nunito_700Bold", fontSize: 16, color: Colors.text },
  inputWrapper: { backgroundColor: Colors.white, borderRadius: 14, alignItems: "center", shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.06, shadowRadius: 8, elevation: 2 },
  codeInput: { fontFamily: "Nunito_800ExtraBold", fontSize: 28, color: Colors.text, textAlign: "center", paddingVertical: 20, paddingHorizontal: 24, letterSpacing: 6, width: "100%" },
});
