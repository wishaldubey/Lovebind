import * as TaskManager from "expo-task-manager";
import * as Location from "expo-location";
import { ref, set } from "firebase/database";
import { db } from "@/lib/firebase";

const LOCATION_TASK_NAME = "BACKGROUND_LOCATION_TASK";
const WEATHER_API_KEY = process.env.EXPO_PUBLIC_OPENWEATHER_API_KEY || "";

async function fetchWeather(lat: number, lng: number) {
  try {
    const url = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lng}&appid=${WEATHER_API_KEY}&units=metric`;
    const res = await fetch(url);
    const data = await res.json();
    return {
      city: data.name || "Unknown",
      weatherTemp: Math.round(data.main?.temp || 0),
      weatherIcon: data.weather?.[0]?.icon || "01d",
    };
  } catch {
    return { city: "Unknown", weatherTemp: 0, weatherIcon: "01d" };
  }
}

TaskManager.defineTask(LOCATION_TASK_NAME, async ({ data, error }: any) => {
  if (error) {
    console.error("Background location error:", error);
    return;
  }
  if (data) {
    const { locations } = data;
    const location = locations[0];
    if (!location) return;

    const { latitude: lat, longitude: lng } = location.coords;

    // We store userId and coupleId in task options - but TaskManager doesn't pass them
    // So we rely on AsyncStorage
    try {
      const AsyncStorage = require("@react-native-async-storage/async-storage").default;
      const userId = await AsyncStorage.getItem("locationUserId");
      const coupleId = await AsyncStorage.getItem("coupleId");

      if (!userId || !coupleId) return;

      const weather = await fetchWeather(lat, lng);

      await set(ref(db, `couples/${coupleId}/location/${userId}`), {
        lat,
        lng,
        timestamp: Date.now(),
        isSharing: true,
        ...weather,
      });
    } catch (e) {
      console.error("Failed to update location:", e);
    }
  }
});

export async function startLocationUpdates(userId: string, coupleId: string): Promise<boolean> {
  try {
    const { status: fgStatus } = await Location.requestForegroundPermissionsAsync();
    if (fgStatus !== "granted") return false;

    const { status: bgStatus } = await Location.requestBackgroundPermissionsAsync();
    if (bgStatus !== "granted") return false;

    const AsyncStorage = require("@react-native-async-storage/async-storage").default;
    await AsyncStorage.setItem("locationUserId", userId);
    await AsyncStorage.setItem("coupleId", coupleId);

    const isRegistered = await TaskManager.isTaskRegisteredAsync(LOCATION_TASK_NAME);
    if (!isRegistered) {
      await Location.startLocationUpdatesAsync(LOCATION_TASK_NAME, {
        accuracy: Location.Accuracy.Balanced,
        timeInterval: 15 * 60 * 1000,
        distanceInterval: 100,
        deferredUpdatesInterval: 15 * 60 * 1000,
        showsBackgroundLocationIndicator: true,
        foregroundService: {
          notificationTitle: "Lovebind",
          notificationBody: "Sharing your location with your partner 💕",
          notificationColor: "#FF6B9D",
        },
      });
    }
    return true;
  } catch (error) {
    console.error("Failed to start location updates:", error);
    return false;
  }
}

export async function stopLocationUpdates(userId: string, coupleId: string) {
  try {
    const isRegistered = await TaskManager.isTaskRegisteredAsync(LOCATION_TASK_NAME);
    if (isRegistered) {
      await Location.stopLocationUpdatesAsync(LOCATION_TASK_NAME);
    }
    await set(ref(db, `couples/${coupleId}/location/${userId}/isSharing`), false);
  } catch (error) {
    console.error("Failed to stop location updates:", error);
  }
}

export async function updateLocationOnce(userId: string, coupleId: string) {
  try {
    const { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== "granted") return;

    const location = await Location.getCurrentPositionAsync({
      accuracy: Location.Accuracy.Balanced,
    });

    const { latitude: lat, longitude: lng } = location.coords;
    const weather = await fetchWeather(lat, lng);

    await set(ref(db, `couples/${coupleId}/location/${userId}`), {
      lat,
      lng,
      timestamp: Date.now(),
      isSharing: true,
      ...weather,
    });
  } catch (error) {
    console.error("Failed to update location once:", error);
  }
}

export { LOCATION_TASK_NAME, fetchWeather };
