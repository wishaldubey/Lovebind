import { Dimensions, PixelRatio } from "react-native";

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get("window");

export const wp = (percentage: number) => (percentage * SCREEN_WIDTH) / 100;
export const hp = (percentage: number) => (percentage * SCREEN_HEIGHT) / 100;

const fontScale = PixelRatio.getFontScale();

export const scaledFont = (size: number) => size / fontScale;

export const MIN_BUTTON_HEIGHT = 48;

export { SCREEN_WIDTH, SCREEN_HEIGHT };
