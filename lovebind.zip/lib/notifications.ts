import { Platform } from "react-native";
import Constants from "expo-constants";
import { ref, set } from "firebase/database";
import { db } from "@/lib/firebase";

// Lazy-load expo-notifications to avoid crash in Expo Go (SDK 53+)
let NotificationsModule: any = null;

async function getNotificationsModule() {
  if (NotificationsModule) return NotificationsModule;
  try {
    const mod = await import("expo-notifications");
    // Dynamic import returns a module namespace; use .default if available, otherwise the mod itself
    NotificationsModule = mod.default || mod;
    return NotificationsModule;
  } catch {
    console.warn("expo-notifications not available (Expo Go limitation)");
    return null;
  }
}

export async function registerForPushNotifications(userId: string) {
  try {
    const Notifications = await getNotificationsModule();
    if (!Notifications) return;

    if (typeof Notifications.getPermissionsAsync !== "function") {
      console.warn("Notifications module does not support getPermissionsAsync");
      return;
    }

    const { status: existingStatus } = await Notifications.getPermissionsAsync();
    let finalStatus = existingStatus;

    if (existingStatus !== "granted") {
      const { status } = await Notifications.requestPermissionsAsync();
      finalStatus = status;
    }

    if (finalStatus !== "granted") {
      console.log("Push notification permission not granted");
      return;
    }

    // Get Expo push token
    const projectId = Constants.expoConfig?.extra?.eas?.projectId;
    if (!projectId) {
      console.warn("No EAS project ID found — skipping push token registration");
      return;
    }

    const tokenData = await Notifications.getExpoPushTokenAsync({ projectId });
    const token = tokenData.data;

    // Save token to Firebase
    await set(ref(db, `users/${userId}/pushToken`), token);

    // Set notification channel for Android
    if (Platform.OS === "android" && Notifications.setNotificationChannelAsync) {
      const importance = Notifications.AndroidImportance?.MAX ?? 5;
      Notifications.setNotificationChannelAsync("default", {
        name: "Default",
        importance,
        vibrationPattern: [0, 250, 250, 250],
        lightColor: "#FF6B9D",
      });
    }
  } catch (e) {
    console.warn("Push notifications not available:", e);
  }
}

export async function sendPushNotification(
  expoPushToken: string,
  title: string,
  body: string,
  data?: Record<string, any>
) {
  try {
    await fetch("https://exp.host/--/api/v2/push/send", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Accept-encoding": "gzip, deflate",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        to: expoPushToken,
        sound: "default",
        title,
        body,
        data: data || {},
      }),
    });
  } catch (e) {
    console.warn("Failed to send push notification:", e);
  }
}

export async function setupNotificationResponseHandler(
  handler: (response: any) => void
) {
  try {
    const Notifications = await getNotificationsModule();
    if (!Notifications || typeof Notifications.addNotificationResponseReceivedListener !== "function") return;
    Notifications.addNotificationResponseReceivedListener(handler);
  } catch {
    // Silently fail in Expo Go
  }
}
