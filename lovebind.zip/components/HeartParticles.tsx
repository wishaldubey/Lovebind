import React, { useEffect } from "react";
import { StyleSheet, View } from "react-native";
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  withRepeat,
  withDelay,
  Easing,
  withSequence,
} from "react-native-reanimated";
import { SCREEN_WIDTH, SCREEN_HEIGHT } from "@/lib/responsive";

const HEART_COUNT = 12;

function FloatingHeart({ index }: { index: number }) {
  const translateY = useSharedValue(SCREEN_HEIGHT + 50);
  const translateX = useSharedValue(Math.random() * SCREEN_WIDTH);
  const opacity = useSharedValue(0);
  const scale = useSharedValue(0.3 + Math.random() * 0.7);
  const rotation = useSharedValue(0);

  useEffect(() => {
    const delay = index * 800 + Math.random() * 2000;
    const duration = 4000 + Math.random() * 3000;

    translateX.value = Math.random() * (SCREEN_WIDTH - 40);

    translateY.value = withDelay(
      delay,
      withRepeat(
        withTiming(-60, { duration, easing: Easing.out(Easing.quad) }),
        -1,
        false
      )
    );

    opacity.value = withDelay(
      delay,
      withRepeat(
        withSequence(
          withTiming(0.7, { duration: duration * 0.2 }),
          withTiming(0.7, { duration: duration * 0.5 }),
          withTiming(0, { duration: duration * 0.3 })
        ),
        -1,
        false
      )
    );

    rotation.value = withDelay(
      delay,
      withRepeat(
        withTiming(360, { duration: duration * 2, easing: Easing.linear }),
        -1,
        false
      )
    );
  }, []);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [
      { translateX: translateX.value },
      { translateY: translateY.value },
      { scale: scale.value },
      { rotate: `${rotation.value}deg` },
    ],
    opacity: opacity.value,
  }));

  const hearts = ["❤️", "💕", "💖", "💗", "💝", "🩷"];
  const heart = hearts[index % hearts.length];

  return (
    <Animated.Text style={[styles.heart, animatedStyle]}>
      {heart}
    </Animated.Text>
  );
}

export default function HeartParticles() {
  return (
    <View style={styles.container} pointerEvents="none">
      {Array.from({ length: HEART_COUNT }, (_, i) => (
        <FloatingHeart key={i} index={i} />
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    ...StyleSheet.absoluteFillObject,
    zIndex: 999,
    pointerEvents: "none",
  },
  heart: {
    position: "absolute",
    fontSize: 24,
  },
});
